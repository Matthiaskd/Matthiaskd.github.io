#include <stdio.h>
#include <err.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include "interface.h"

void run_kernel(kernel* ker) {
    int quit = 0;
    input *data = malloc(sizeof(input));
    data->left = 0;

    SDL_Event event;
    SDL_SetRenderDrawBlendMode(ker->renderer, SDL_BLENDMODE_BLEND);
    draw_object(ker->renderer, ker->root, data, ker->root->rect, ker->root->rect);
    SDL_RenderPresent(ker->renderer);

    while (!quit) {
        SDL_WaitEvent(&event);
        data->key = 0;
        data->backspace = 0;
        data->enter = 0;

		if (event.type == SDL_QUIT)
			quit = 1;
        else if (ker->root == NULL)
            continue;
		else if (event.type == SDL_MOUSEMOTION) {
            data->dx = event.motion.x - data->x;
            data->dy = event.motion.y - data->y;
			data->x = event.motion.x;
			data->y = event.motion.y;
		}
        else if (event.type == SDL_TEXTINPUT) {
            data->key = event.text.text[0];
        }
        else if (event.type == SDL_KEYDOWN) {
            data->backspace = event.key.keysym.sym == SDLK_BACKSPACE;
            data->enter = event.key.keysym.sym == SDLK_RETURN || event.key.keysym.sym == SDLK_KP_ENTER;
        }
        else if (event.type == SDL_MOUSEWHEEL) {
            if (event.wheel.y > 0)
                data->dwheel = 1;
            else
                data->dwheel = -1;
        }
		else {
            int oldleft = data->left;
            int oldright = data->right;

            if (event.type == SDL_MOUSEBUTTONDOWN) {
                if (event.button.button == SDL_BUTTON_LEFT)
                    data->left = 1;
                if (event.button.button == SDL_BUTTON_RIGHT)
                    data->right = 1;
            }
            else if (event.type == SDL_MOUSEBUTTONUP) {
                if (event.button.button == SDL_BUTTON_LEFT)
                    data->left = 0;
                if (event.button.button == SDL_BUTTON_RIGHT)
                    data->right = 0;
            }

            data->dleft = oldleft != data->left;
            data->dright = oldright != data->right;
            data->dwheel = 0;
        }

        draw_object(ker->renderer, ker->root, data, ker->root->rect, ker->root->rect);
        SDL_RenderPresent(ker->renderer);
    }

    free(data);
}

int draw_object(SDL_Renderer *renderer, object *obj, input *data, SDL_Rect rect1, SDL_Rect rect2) {
    SDL_Rect target;
    SDL_Rect curr = obj->rect;
    curr.x += rect1.x;
    curr.y += rect1.y;

    SDL_IntersectRect(&rect1, &curr, &target);
    SDL_IntersectRect(&rect2, &target, &target);

    if (!SDL_RectEmpty(&target)) {
        SDL_Texture* targetTexture = SDL_CreateTexture(
                renderer, 
                SDL_PIXELFORMAT_RGBA8888, 
                SDL_TEXTUREACCESS_TARGET, 
                target.w, 
                target.h);

        SDL_SetRenderTarget(renderer, targetTexture);
        SDL_Rect rect = {0, 0, target.w, target.h};

        SDL_SetRenderDrawColor(
            renderer, 
            obj->background.r, 
            obj->background.g, 
            obj->background.b, 
            obj->background.a);
        SDL_RenderFillRect(renderer, &rect);

        SDL_SetRenderDrawColor(
            renderer, 
            obj->border.r, 
            obj->border.g, 
            obj->border.b, 
            obj->border.a);
        SDL_RenderDrawRect(renderer, &rect);

        if (obj->type != -1) {
            SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, obj->content);
            // TODO clip left and top sides
            SDL_Rect  size;
            if (obj->type) {
                size.x = (target.w - obj->content->w)/2;
                size.y = (target.h - obj->content->h)/2;
                size.w = obj->content->w;
                size.h = obj->content->h;
            }
            else {
                size.x = 0;
                size.y = 0;
                size.w = curr.w;
                size.h = curr.h;
            }
            SDL_RenderCopy(renderer, texture, NULL, &size);
            SDL_DestroyTexture(texture);
        }

        SDL_SetRenderTarget(renderer, NULL);
        SDL_RenderCopy(renderer, targetTexture, NULL, &target);
        SDL_DestroyTexture(targetTexture);
    }
    
    int childrens = 0;
    for (object* child = obj->child->sibling; child != NULL; child = child->sibling)
        childrens = draw_object(renderer, child, data, curr, target) || childrens;
    
    /* TODO siblings collision conflict
    int siblings = 0;
    for (object* sibling = obj->parent->child->sibling; sibling != obj; sibling = sibling->sibling)
        childrens = draw_object(renderer, sibling, data, curr, target) || childrens;
    */

    int comp = !childrens && 
        data->x >= target.x && data->x <= target.x + target.w &&
        data->y >= target.y && data->y <= target.y + target.h;

    if (obj->update != NULL) {
        data->obj = obj;
        obj->update(data, comp);
    }
    
    return childrens || comp;
}

kernel *malloc_kernel(int width, int height) {
    if (SDL_Init(SDL_INIT_VIDEO) != 0 || TTF_Init() != 0)
        errx(EXIT_FAILURE, "%s", SDL_GetError());

    kernel* ker = malloc(sizeof(kernel));

    if (ker == NULL)
        errx(EXIT_FAILURE, "Not enough memory.\n");

    ker->root = NULL;
    ker->window = SDL_CreateWindow(
		    "SEDA Calculator",
		    SDL_WINDOWPOS_UNDEFINED,
		    SDL_WINDOWPOS_UNDEFINED,
		    width,
		    height,
		    SDL_WINDOW_SHOWN | SDL_WINDOW_OPENGL);
    ker->renderer = SDL_CreateRenderer(ker->window, -1, 0);
    
    return ker;
}

object *malloc_object() {
    object *obj = malloc(sizeof(object));

    if (obj == NULL)
        errx(EXIT_FAILURE, "Not enough memory.\n");

    obj->active = 0;
    obj->offset = 1;

    // sentinel
    obj->child = malloc(sizeof(object));
    obj->child->sibling = NULL;

    obj->parent = NULL;
    obj->sibling = NULL;

    obj->rect = (SDL_Rect){0, 0, 0, 0};
    obj->background = (SDL_Color){0, 0, 0, 0};
    obj->border = (SDL_Color){0, 0, 0, 0};

    obj->type = -1;
    obj->content = NULL;

    obj->update = NULL;
    
    return obj;
}

void insert_object(object *obj, object* parent) {
    object* child = parent->child;
    while (child->sibling != NULL && child->sibling->offset < obj->offset)
        child = child->sibling;
    
    obj->parent = parent;
    obj->sibling = child->sibling;
    child->sibling = obj;
}

void remove_object(object *obj) {
    object *child = obj->parent->child;
    while (child->sibling != obj)
        child = child->sibling;
    
    child->sibling = obj->sibling;
    obj->parent = NULL;
}

void set_image(object *obj, SDL_Color color, char* path) {
    obj->type = 0;
    obj->content = IMG_Load(path);
	
	Uint32* pixels = obj->content->pixels;
	int len = obj->content->w * obj->content->h;
	SDL_PixelFormat* f = obj->content->format;
				
	SDL_LockSurface(obj->content);
	for (int i = 0; i < len; i++) {
		Uint8 r, g, b, a;
		SDL_GetRGBA(pixels[i], f, &r, &g, &b, &a);
		if (a != 0)
			pixels[i] = SDL_MapRGBA(
				f, color.r, color.g, color.b, a);
	}
	SDL_UnlockSurface(obj->content);
}

void set_text(object* obj, SDL_Color color, TTF_Font* font, char* content) {
    obj->type = 1;
    obj->content = TTF_RenderText_Solid(font, content, color);
}

void free_kernel(kernel *ker) {
    if (ker->root != NULL)
        free_object(ker->root);
    
    SDL_DestroyRenderer(ker->renderer);
    SDL_DestroyWindow(ker->window);

    free(ker);

    TTF_Quit();
    SDL_Quit();
}

void free_object(object *obj) {
    // TODO free objects at suffix order
    /*
    for (object *child = obj->child->sibling; child != NULL; child = child->sibling)
        free_object(child);
    
    if (obj->type != -1)
        SDL_FreeSurface(obj->content);
    
    free(obj->sibling); // sentinel
    */
    free(obj);
}