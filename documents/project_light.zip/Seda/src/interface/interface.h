#ifndef INTERFACE
#define INTERFACE

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>

typedef struct object object;

typedef struct input
{
    // mouse
    int x;
    int y;
    int dx;
    int dy;
    int left;
    int right;
    int dleft;
    int dright;
    int dwheel;

    // keyboard
    char key;
    int backspace;
    int enter;

    // object
    object* obj;

} input;

typedef struct object
{
    int active;
    int offset;
    object *child;
    object *parent;
    object *sibling;

    // position and size
    SDL_Rect rect;

    // theme
    SDL_Color background;
    SDL_Color border;

    // content
    int type; // text = 1 image = 0
    SDL_Surface* content;

    // loop function
    void (*update)(input *data, int collision);

} object;

typedef struct kernel
{
    object *root;

    // SDL stuff
    SDL_Window *window;
    SDL_Renderer *renderer;

} kernel;

void run_kernel(kernel* ker);
int draw_object(SDL_Renderer* renderer, object* obj, input* data, SDL_Rect rect1, SDL_Rect rect2);

kernel* malloc_kernel(int width, int height);
object* malloc_object();

void insert_object(object* obj, object *parent);
void remove_object(object* obj);

void set_image(object* obj, SDL_Color color, char* path);
void set_text(object* obj, SDL_Color color, TTF_Font* font, char* content);

void free_kernel(kernel* ker);
void free_object(object* obj);

#endif