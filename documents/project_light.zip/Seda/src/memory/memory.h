#ifndef FILE_STACK_H
#define FILE_STACK_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void write_in_file(const char *content);
char** read_in_file(int* num_lines);

struct MemoryStack {
  int data;
  struct MemoryStack *next;
};

void write_stack(struct MemoryStack **head, int data);
int read_stack(struct MemoryStack **head);

void clear_all();

#endif