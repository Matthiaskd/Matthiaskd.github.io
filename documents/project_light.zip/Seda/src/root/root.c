#include<stdio.h>
#include<stdlib.h>
#include"poly.h"
#include<math.h>
#include<pthread.h>
#include "ShuntingYard.h"
#include "lexer.h"


#define STEP 1
#define TOLERANCE 0.00000001
#define NMAX 10

const size_t root_5=0;
const size_t root_2=0;
const size_t root_3=0;



double evaluate(struct poly* q, double x){
    struct poly* p = q;
    p=p->next;
    double res = 0;
    while(p){
        double deg = p->degree;
        double sum = 1;
        while(deg>0){
            sum*=x;
            deg-=1;
        }
        sum*=(p->value);
        res+=sum;
        p = p->next;
    }
    return res;
}


struct solution* bisection(struct poly* p, double a, double b){//sent->next = NULL=> no solution with the given a and b 
    if(a<b){
        double n =1;
        while(n <= NMAX){
            double c = (a+b)/2;
            if(evaluate(p, c) == 0 ||((b-a)/2<TOLERANCE)){
                struct solution* res = init_solution();
                res->value = c;
                return res;
            }
            n+=1;
            if(evaluate(p, a)*evaluate(p, c)>0)
                a = c;
            else    
                b = c;
        }
    }
    return NULL;
}
struct poly* f_prime(struct poly* p){ //derivates the polynome
    struct poly* prime = init();
    struct poly* prime2 = prime;
    struct poly* p2 = p->next;
    while(p2){
        struct poly* new = init();
        new->value = p2->value * p2->degree;
        new->degree = p2->degree -1;
        prime2->next = new;
        prime = prime->next;
        p2=p2->next;
    }
    flattern(prime);
    return prime;
}

struct solution* aux_find_root(struct poly* p, double inf){
    double i = 0;
    while(i<=NMAX){
        if(evaluate(p, i+inf)==0){
            struct solution* n = init_solution();
            n->value = i+inf;
            return n;
        }
        else if(evaluate(p, i+inf)<0){
            if(evaluate(p, inf)>0){
                return bisection(p, inf, i+inf);
            }
        }
        else if(evaluate(p, i+inf)>0){
            if(evaluate(p, inf)<0)
                return bisection(p, inf, i+inf);
        }
        i += STEP;
    }
    return NULL;
}

double find_root(struct poly* p){
    struct poly* q = p;
    if(evaluate(q, 0)==0)
        return 0;
    else{
        struct poly* q1 = p;
        struct poly* q2 = p;
    
        struct solution* res = aux_find_root(q1,-NMAX);
        if(res!=NULL){
            double ev1 = evaluate(p, res->value);
            if(ev1<TOLERANCE && ev1>-TOLERANCE){
                double r =  res->value;
                free_solution(res);
                return r;
            }
            free_solution(res);
        }
        res = aux_find_root(q2,0);
        if(res!=NULL){
            double ev1 = evaluate(p, res->value);//prob hrerere !!!!!!!
            if(ev1<TOLERANCE && ev1>-TOLERANCE){
                double r = res->value;
                free_solution(res);
                return r;
            }
            free_solution(res);
        }
        return -12;
    }
}


struct solution* linear(struct poly* p){
    struct solution* s = init_solution();
    if(p->degree>=1 && p->next == NULL){
        s->value = 0;
    }
    if(p->next){
        s->value = 0;
        if(p->next->next){
            s->value = -p->next->next->value/p->next->value;
        }
    }
    return s;
}
//returns NULL if no real solution is found
struct solution* remarkable(struct poly* p){//returns NULL if no solution in R
    double factors[3]={0};
    struct poly* q = p;
    q= q->next;
    int k;
    while(q){
        k = 2-q->degree; //<=2
        factors[k] = q->value;
        q=q->next;
    }
    double delta = factors[1]*factors[1] - 4*factors[0]*factors[2];
    if(delta>=0){
        struct solution* s = init_solution();
        s->value = (-factors[1] - sqrt(delta))/(2*factors[0]);
        s->next = init_solution();
        s->next->value = (-factors[1] + sqrt(delta))/(2*factors[0]);
        return s;
    }
    return NULL;
}


struct solution* non_remarkable(struct poly *p){
    struct solution* s = NULL;
    struct poly* q = p;
    double root;
    struct poly* tmp = NULL;
    while(q && q->next && q->next->degree>2){

        root = find_root(q);
        double ev = evaluate(p, root);
        if(ev>-TOLERANCE && ev<TOLERANCE){
            struct solution* s2 = init_solution();
            s2->value = root;
            if(s == NULL)
                s = s2;
            else
                append_s(s, s2);
            tmp = q;
            if(q != tmp && q!=p)
                free_poly(q);
            q = factorise(tmp, root);
        }
        else{
            break;
        }

    }   
    if(tmp!=NULL && tmp!=p){
        free_poly(tmp);
        tmp = NULL;
    }
    if(q->next->degree==2){
        struct solution* s2 = remarkable(q);
        if(s2!=NULL)
            append_s(s, s2);
    }
    if(q!=NULL && q!=p)
        free_poly(q);
    return s;
}

struct solution* solve(struct poly* p){
        if(p==NULL)
            return NULL;
        struct solution* sol;
        if(p->next && p->next->degree == 0)
            sol = NULL;
        else if(p->next && p->next->degree==1){
            //printf("linear\n");
            sol = linear(p);
        }
        else if(p->next->degree <= 2){
            //printf("remarkable\n");
            sol = remarkable(p);
        }
        else if(p->next->degree>2){
            //printf("non remarkable\n");
            sol = non_remarkable(p);
        }
        return sol;
}


int in(char* str, char x){
    for(int i = 0; str[i]!=0; i++){
        if(str[i]==x)
            return 1;
    }
    return 0;
}

int is_valid(char* expr){
    for(int k = 0; expr[k]!=0; k++){
        if(! in("0123456789+^-/*x()", expr[k])){
            return 0;
        }
    }
    for(int i=0; expr[i]!=0; i++){
        if(expr[i]=='/'){
            if(expr[i+1]=='('){
                int j = i+1;
                while(expr[j]!=0){
                    if(expr[j]==')')
                        break;
                    else if (expr[j]=='x')
                        return 0;
                }
            }
        }
    }
    return 1;
}

struct poly* build_poly(char* expr){
    if(! is_valid(expr))
        return NULL;
    struct queue* q = ShuntingYard(lex(expr));
    struct poly* P  = eval(q);
    
    flattern(P);
    sort(P);
    return P;
}


