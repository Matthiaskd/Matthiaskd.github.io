#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "interface.h"
#include "shunting_yard.h"
#include "memory.h"
#include "queue_stack.h"
#include "lexer.h"
#include "ShuntingYard.h"
#include "poly.h"
#include "root.h"

int width = 450, height = 636;

int main() {
    kernel* ker = malloc_kernel(width, height);

    
    TTF_Font* arial = TTF_OpenFont("fonts/arial.ttf", 18);

    object* home = malloc_object();
    home->rect = (SDL_Rect){0, 0, width, height};
    home->background = (SDL_Color){180, 180, 180, 255};
    ker->root = home;

    object* calculator = malloc_object();
    calculator->rect = (SDL_Rect){0, 0, width, height};
    calculator->background = (SDL_Color){180, 180, 180, 255};

    object* grapher = malloc_object();
    grapher->rect = (SDL_Rect){0, 0, width, height};
    grapher->background = (SDL_Color){180, 180, 180, 255};

    object* python = malloc_object();
    python->rect = (SDL_Rect){0, 0, width, height};
    python->background = (SDL_Color){180, 180, 180, 255};

    object* pythonOutput = malloc_object();
    pythonOutput->rect = (SDL_Rect){0, 0, width, height};
    pythonOutput->background = (SDL_Color){180, 180, 180, 255};

    object* polynomials = malloc_object();
    polynomials->rect = (SDL_Rect){0, 0, width, height};
    polynomials->background = (SDL_Color){180, 180, 180, 255};

    // bottomBar ---------------------------------------------------------------
    object* bottomBar = malloc_object();
    bottomBar->rect = (SDL_Rect){0, height - 36, width, 36};
    bottomBar->background = (SDL_Color){80, 80, 80, 255};

    
    object* backButton = malloc_object();
    backButton->rect = (SDL_Rect){width - 80, 8, 0, 0};
    set_text(backButton, (SDL_Color){80, 80, 80, 0}, arial, "Stop");
    insert_object(backButton, bottomBar);

    object* homeButton = malloc_object();
    homeButton->rect = (SDL_Rect){(width - 30)/2, 3, 30, 30};
    homeButton->background = (SDL_Color){80, 80, 80, 255};
    set_image(homeButton, (SDL_Color){160, 160, 160, 0}, "assets/home.png");
    insert_object(homeButton, bottomBar);

    void updateBackButton(input* data, int collision) {
        if (collision) {
            if (data->dleft && data->left) {
                backButton->rect = (SDL_Rect){width - 80, 8, 0, 0};
                homeButton->rect = (SDL_Rect){(width - 30)/2, 3, 30, 30};
                ker->root = python;
            }
            backButton->background = (SDL_Color){140, 140, 140, 255};
        }
        else {
            backButton->background = (SDL_Color){160, 160, 160, 255};
        }
    }
    backButton->update = updateBackButton;

    void updateHomeButton(input* data, int collision) {
        if (collision) {
            if (data->dleft && data->left) {
                ker->root = home;
            }
            set_image(homeButton, (SDL_Color){140, 140, 140, 0}, "assets/home.png");
        }
        else {
            set_image(homeButton, (SDL_Color){160, 160, 160, 0}, "assets/home.png");
        }
    }
    homeButton->update = updateHomeButton;

    insert_object(bottomBar, home);
    insert_object(bottomBar, calculator);
    insert_object(bottomBar, grapher);
    insert_object(bottomBar, python);
    insert_object(bottomBar, pythonOutput);
    insert_object(bottomBar, polynomials);

    // home --------------------------------------------------------------------
    object* homeTitle = malloc_object();
    homeTitle->rect = (SDL_Rect){0, 60, width, 100};
    homeTitle->background = (SDL_Color){180, 180, 180, 255};
    homeTitle->border = homeTitle->background;
    set_text(homeTitle, (SDL_Color){150, 150, 150, 0}, TTF_OpenFont("fonts/square.ttf", 100), "SEDA");
    insert_object(homeTitle, home);

    object* square = malloc_object();
    square->offset = 0;
    square->rect = (SDL_Rect){width, height, 60, 60};
    square->background = (SDL_Color){140, 140, 140, 255};
    square->border = square->background;
    insert_object(square, home);

    object* calculatorButton = malloc_object();
    calculatorButton->rect = (SDL_Rect){50, 220, 50, 50};
    insert_object(calculatorButton, home);

    object* calculatorText = malloc_object();
    calculatorText->rect = (SDL_Rect){20, 280, 110, 20};
    insert_object(calculatorText, home);

    void setCalculator(input* data, int collision) {
        if (collision) {
            if (data->dleft && data->left)
                ker->root = calculator;
            else {
                square->rect = (SDL_Rect){45, 215, 60, 60};
                calculatorButton->background = (SDL_Color){140, 140, 140, 255};
                calculatorText->background = (SDL_Color){140, 140, 140, 255};
                set_image(calculatorButton, (SDL_Color){180, 180, 180, 0}, "assets/calculations.png");
                set_text(calculatorText, (SDL_Color){180, 180, 180, 0}, arial, "Calculations");
            }
        }
        else {
            if (square->rect.x == 45)
                square->rect = (SDL_Rect){width, height, 60, 60};
            calculatorButton->background = (SDL_Color){180, 180, 180, 255};
            calculatorText->background = (SDL_Color){180, 180, 180, 255};
            set_image(calculatorButton, (SDL_Color){140, 140, 140, 0}, "assets/calculations.png");
            set_text(calculatorText, (SDL_Color){140, 140, 140, 0}, arial, "Calculations");
        }
        calculatorButton->border = calculatorButton->background;
    }
    calculatorButton->update = setCalculator;

    object* grapherButton = malloc_object();
    grapherButton->rect = (SDL_Rect){200, 220, 50, 50};
    insert_object(grapherButton, home);

    object* grapherText = malloc_object();
    grapherText->rect = (SDL_Rect){170, 280, 110, 20};
    insert_object(grapherText, home);

    void setGrapher(input* data, int collision) {
        if (collision) {
            if (data->dleft && data->left)
                ker->root = grapher;
            else {
                square->rect = (SDL_Rect){195, 215, 60, 60};
                grapherButton->background = (SDL_Color){140, 140, 140, 255};
                grapherText->background = (SDL_Color){140, 140, 140, 255};
                set_image(grapherButton, (SDL_Color){180, 180, 180, 0}, "assets/grapher.png");
                set_text(grapherText, (SDL_Color){180, 180, 180, 0}, arial, "Grapher");
            }
        }
        else {
            if (square->rect.x == 195)
                square->rect = (SDL_Rect){width, height, 60, 60};
            grapherButton->background = (SDL_Color){180, 180, 180, 255};
            grapherText->background = (SDL_Color){180, 180, 180, 255};
            set_image(grapherButton, (SDL_Color){140, 140, 140, 0}, "assets/grapher.png");
            set_text(grapherText, (SDL_Color){140, 140, 140, 0}, arial, "Grapher");
        }
        grapherButton->border = grapherButton->background;
    }
    grapherButton->update = setGrapher;

    object* pythonButton = malloc_object();
    pythonButton->rect = (SDL_Rect){350, 220, 50, 50};
    insert_object(pythonButton, home);

    object* pythonText = malloc_object();
    pythonText->rect = (SDL_Rect){320, 280, 110, 20};
    insert_object(pythonText, home);

    void setPython(input* data, int collision) {
        if (collision) {
            if (data->dleft && data->left)
                ker->root = python;
            else {
                square->rect = (SDL_Rect){345, 215, 60, 60};
                pythonButton->background = (SDL_Color){140, 140, 140, 255};
                pythonText->background = (SDL_Color){140, 140, 140, 255};
                set_image(pythonButton, (SDL_Color){180, 180, 180, 0}, "assets/python.png");
                set_text(pythonText, (SDL_Color){180, 180, 180, 0}, arial, "Python");
            }
        }
        else {
            if (square->rect.x == 345)
                square->rect = (SDL_Rect){width, height, 60, 60};
            pythonButton->background = (SDL_Color){180, 180, 180, 255};
            pythonText->background = (SDL_Color){180, 180, 180, 255};
            set_image(pythonButton, (SDL_Color){140, 140, 140, 0}, "assets/python.png");
            set_text(pythonText, (SDL_Color){140, 140, 140, 0}, arial, "Python");
        }
        pythonButton->border = pythonButton->background;
    }
    pythonButton->update = setPython;

    object* polyButton = malloc_object();
    polyButton->rect = (SDL_Rect){50, 320, 50, 50};
    insert_object(polyButton, home);

    object* polyText = malloc_object();
    polyText->rect = (SDL_Rect){20, 380, 110, 20};
    insert_object(polyText, home);

    void setPoly(input* data, int collision) {
        if (collision) {
            if (data->dleft && data->left)
                ker->root = polynomials;
            else {
                square->rect = (SDL_Rect){345, 215, 60, 60};
                polyButton->background = (SDL_Color){140, 140, 140, 255};
                polyText->background = (SDL_Color){140, 140, 140, 255};
                set_image(polyButton, (SDL_Color){180, 180, 180, 0}, "assets/power.png");
                set_text(polyText, (SDL_Color){180, 180, 180, 0}, arial, "Polynomials");
            }
        }
        else {
            if (square->rect.x == 345)
                square->rect = (SDL_Rect){width, height, 60, 60};
            polyButton->background = (SDL_Color){180, 180, 180, 255};
            polyText->background = (SDL_Color){180, 180, 180, 255};
            set_image(polyButton, (SDL_Color){140, 140, 140, 0}, "assets/power.png");
            set_text(polyText, (SDL_Color){140, 140, 140, 0}, arial, "Polynomials");
        }
        polyButton->border = polyButton->background;
    }
    polyButton->update = setPoly;

    // calculations ------------------------------------------------------------
    object* output = malloc_object();
    output->rect = (SDL_Rect){5, 5, width-10, width-10};
    output->background = (SDL_Color){170, 170, 170, 255};
    output->border = (SDL_Color){150, 150, 150, 255};
    insert_object(output, calculator);

    object* outputTitle = malloc_object();
    outputTitle->offset = 0;
    outputTitle->rect = (SDL_Rect){0, (width-110)/2, width-10, 100};
    outputTitle->background = (SDL_Color){170, 170, 170, 255};
    outputTitle->border = outputTitle->background;
    set_text(outputTitle, (SDL_Color){160, 160, 160, 0}, TTF_OpenFont("fonts/square.ttf", 100), "SEDA");
    insert_object(outputTitle, output);

    object* calcInput = malloc_object();
    calcInput->rect = (SDL_Rect){5, width-5, width-10, 30};
    calcInput->background = (SDL_Color){170, 170, 170, 255};
    calcInput->border = (SDL_Color){150, 150, 150, 255};
    insert_object(calcInput, calculator);

    object* inputText = malloc_object();
    inputText->rect = (SDL_Rect){1, 1, width-12, 28};
    inputText->background = (SDL_Color){170, 170, 170, 255};
    insert_object(inputText, calcInput);

    object* clearMemory = malloc_object();
    clearMemory->rect = (SDL_Rect){width/2 - 70, calcInput->rect.y + 40, 140, 20};
    clearMemory->background = (SDL_Color){170, 50, 50, 255};
    set_text(clearMemory, (SDL_Color){200, 200, 200, 0}, arial, "Clear");
    insert_object(clearMemory, calculator);

    char inputBuffer[256] = "0";
    int index = 0;
    int maxMemory = 32;
    object* memory[maxMemory];
    for (int i = 0; i < maxMemory; i++) {
        memory[i] = malloc_object();
        memory[i]->background = (SDL_Color){170, 170, 170, 255};
        memory[i]->offset = 5+i;
        insert_object(memory[i], output);
    }

    void updateMemory() {
        int nb = 0;
        char** lines = read_in_file(&nb);
        //printf("nb=%i\n", nb);
        for (int i = 0; i < maxMemory; i++) {
            memory[i]->rect = (SDL_Rect){0, 0, 0, 0};
        }

        for (int i = 0; i < nb/2; i++) {
            //printf("%s%s", lines[nb-2-2*i], lines[nb-1-2*i]);
            int j = 0;
            while (lines[nb-2-2*i][j] != '\n')
                j++;
            lines[nb-2-2*i][j] = 0;
            j = 0;
            while (lines[nb-1-2*i][j] != '\n')
                j++;
            lines[nb-1-2*i][j] = 0;

            set_text(memory[2*i], (SDL_Color){120, 120, 120, 0}, arial, lines[nb-1-2*i]);
            memory[2*i]->rect = (SDL_Rect){width-45-memory[2*i]->content->w, width-48-40*i, memory[2*i]->content->w, 20};

            set_text(memory[2*i+1], (SDL_Color){120, 120, 120, 0}, arial, lines[nb-2-2*i]);
            memory[2*i+1]->rect = (SDL_Rect){5, width-68-40*i, memory[2*i+1]->content->w, 20};
        }
    }
    updateMemory();

    void updateClear(input* data, int collision) {
        if (collision) {
            clearMemory->border = (SDL_Color){200, 200, 200, 255};
            if (data->dleft && data->left) {
                clear_all();
                updateMemory();
            }
        }
        else {
            clearMemory->border = (SDL_Color){0, 0, 0, 0};
        }
    }
    clearMemory->update = updateClear;

    void updateInput(input* data, int collision) {
        if (collision) {
            if (data->key != '\0') {
                inputBuffer[index] = data->key;
                index++;
                inputBuffer[index] = 0;
            }
            if (data->backspace && index > 1) {
                if (index > 1) {
                    index--;
                    inputBuffer[index] = 0;
                }
                else {
                    inputBuffer[0] = '0';
                    inputBuffer[1] = 0;
                    index = 0;
                }
            }
            if (data->enter) {
                int len = 0; 
                int len_rpn = 0;
                struct Token_Type** res = lexer(inputBuffer,&len);
                struct Token_Type** rpn = RPN(res,len,&len_rpn);
                struct Tree* tree = Build_Tree(rpn,len_rpn);
                double result = computeTree(tree);

                int size = snprintf(NULL, 0, "%f", result);  // Obtenir la taille réelle requise
                char* buffer = malloc(size + 1);  // Allouer l'espace nécessaire
                snprintf(buffer, size + 1, "%f", result);  // Convertir le double en chaîne

                write_in_file(inputBuffer);
                write_in_file(buffer);
                //printf("%s = %s\n", inputBuffer, buffer);
                free(buffer);

                inputBuffer[0] = '0';
                inputBuffer[1] = 0;
                index = 0;

                updateMemory();
                
            }
        }
        set_text(inputText, (SDL_Color){120, 120, 120, 0}, arial, inputBuffer);
        inputText->rect.w = inputText->content->w;
    }
    calcInput->update = updateInput;
    inputText->update = updateInput;

    // grapher -----------------------------------------------------------------
    double xMin = -4.0;
    double xMax = 4.0;
    double yMin = -4.0;
    double yMax = 4.0;
    double interval = 1.0;

    int maxFunctions = 3;
    int functionsCount = 0;
    int currentFunction = -1;
    int functionState[maxFunctions];
    char names[maxFunctions][128];
    char functionsExpr[maxFunctions][256];

    object* functions[maxFunctions];

    object* graphArea = malloc_object();
    graphArea->offset = 0;
    graphArea->rect = (SDL_Rect){0, 0, width, width};
    graphArea->background = (SDL_Color){200, 200, 200, 255};
    insert_object(graphArea, grapher);

    object* yAxis = malloc_object();
    yAxis->offset = 1;
    yAxis->rect = (SDL_Rect){0, 0, 1, graphArea->rect.w};
    yAxis->background = (SDL_Color){80, 80, 80, 255};
    insert_object(yAxis, graphArea);

    object* xAxis = malloc_object();
    xAxis->offset = 1;
    xAxis->rect = (SDL_Rect){0, 0, graphArea->rect.w, 1};
    xAxis->background = (SDL_Color){80, 80, 80, 255};
    insert_object(xAxis, graphArea);

    int maxLines = 32;
    object* yGrid[maxLines];
    object* xGrid[maxLines];
    object* pixels[graphArea->rect.w*maxFunctions];

    void updateGrapher(input* data, int collision) {
        if (collision) {
            double xInterval = (xMax - xMin)/graphArea->rect.w;
            double yInterval = (yMax - yMin)/graphArea->rect.w;

            xMax -= 20*((double)data->dwheel)*xInterval;
            //xMin += 20*((double)data->dwheel)*xInterval;
            yMax -= 20*((double)data->dwheel)*yInterval;
            //yMin += 20*((double)data->dwheel)*yInterval;

            if (data->left) {
                xMax -= ((double)data->dx)*xInterval;
                xMin -= ((double)data->dx)*xInterval;
                yMax += ((double)data->dy)*yInterval;
                yMin += ((double)data->dy)*yInterval;
            }
            
            yAxis->rect.x = -((int)((xMin)/xInterval));
            xAxis->rect.y = graphArea->rect.w+((int)((yMin)/yInterval));

            if ((int)((xMax-xMin)/interval)+1 > maxLines)
                interval *= 10;
            else if ((int)((xMax-xMin)/interval)+1 < 4)
                interval /= 10;

            double offset = xMin - (int)(xMin/interval)*interval;
            int index = 0;
            for (double x = xMin - offset; x <= xMax; x += interval) {
                xGrid[index]->rect.x = (int)((x - xMin)/xInterval);
                index++;
            }
            for (int i = index; i < maxLines; i++)
                xGrid[i]->rect.x = -1;

            offset = yMin - (int)(yMin/interval)*interval;
            index = 0;
            for (double y = yMin - offset; y <= yMax; y += interval) {
                yGrid[index]->rect.y = graphArea->rect.w - (int)((y - yMin)/yInterval);
                index++;
            }
            for (int i = index; i < maxLines; i++)
                yGrid[i]->rect.y = -1;

            int k = -1;
            int step = 2;
            for (int i = 0; i < graphArea->rect.w*maxFunctions; i += step) {
                int xPos = i % graphArea->rect.w;
                k += xPos == 0;

                if (k < functionsCount && functionState[k]) {
                    double x = xMin + xPos * xInterval;

                    int size = snprintf(NULL, 0, "%f", x);  // Obtenir la taille réelle requise
                    char* buffer = malloc(size + 1);  // Allouer l'espace nécessaire
                    snprintf(buffer, size + 1, "%f", x);  // Convertir le double en chaîne

                    size_t length = strlen(functionsExpr[k]);
                    char* result = malloc(length + 1);  // Allouer l'espace pour la nouvelle chaîne

                    // Copier la chaîne d'origine dans la nouvelle chaîne
                    
                    strncpy(result, functionsExpr[k], length + 1);

                    char* pos = strchr(result, 'x');
                    while (pos != NULL) {
                        // Remplacement de 'x' par la chaîne représentant le double
                        memmove(pos + size, pos + 1, strlen(pos + 1) + 1);
                        memcpy(pos, buffer, size);

                        pos = strchr(pos + size, 'x');
                    }

                    free(buffer);  // Libérer la mémoire allouée
                    
                    int len = 0; 
                    int len_rpn = 0;
                    struct Token_Type** res = lexer(result,&len);
                    struct Token_Type** rpn = RPN(res,len,&len_rpn);
                    struct Tree* tree = Build_Tree(rpn,len_rpn);
                    double y = computeTree(tree);
                    
                    int j = (int)((y - yMin)/yInterval);
                    if (j >= 0 && j <= graphArea->rect.w) {
                        pixels[i]->rect = (SDL_Rect){xPos, graphArea->rect.w-1-j, 2, 2};
                        if (xPos > 0 && abs(pixels[i-step]->rect.y - pixels[i]->rect.y) >= 1) {
                            int diff = abs(pixels[i-step]->rect.y - pixels[i]->rect.y);
                            pixels[i]->rect.h = diff;
                        }
                    }
                    else
                        pixels[i]->rect = (SDL_Rect){0, 0, 0, 0};
                }
                else
                    pixels[i]->rect = (SDL_Rect){0, 0, 0, 0};
            }

        }
    }
    graphArea->update = updateGrapher;
    xAxis->update = updateGrapher;
    yAxis->update = updateGrapher;

    for (int i = 0; i < graphArea->rect.w*maxFunctions; i++) {
        pixels[i] = malloc_object();
        pixels[i]->offset = 2;
        pixels[i]->background = (SDL_Color){0, 0, 0, 0};
        pixels[i]->update = updateGrapher;
        insert_object(pixels[i], graphArea);
    }

    for (int i = 0; i < maxLines; i++) {
        yGrid[i] = malloc_object();
        yGrid[i]->offset = 1;
        yGrid[i]->rect = (SDL_Rect){0, 0, graphArea->rect.w, 1};
        yGrid[i]->background = (SDL_Color){180, 180, 180, 255};
        yGrid[i]->update = updateGrapher;

        xGrid[i] = malloc_object();
        xGrid[i]->offset = 1;
        xGrid[i]->rect = (SDL_Rect){0, 0, 1, graphArea->rect.w};
        xGrid[i]->background = (SDL_Color){180, 180, 180, 255};
        xGrid[i]->update = updateGrapher;

        insert_object(yGrid[i], graphArea);
        insert_object(xGrid[i], graphArea);
    }

    object* functionManager = malloc_object();
    functionManager->rect = (SDL_Rect){10, width + 10, width - 20, height - width - 56};
    functionManager->background = (SDL_Color){180, 180, 180, 255};
    insert_object(functionManager, grapher);

    object* functionSelector = malloc_object();
    functionSelector->offset = 2;
    functionSelector->background = (SDL_Color){180, 180, 180, 255};
    insert_object(functionSelector, functionManager);

    object* functionName = malloc_object();
    functionName->rect = (SDL_Rect){0, 25, functionManager->rect.w, 20};
    functionName->background = (SDL_Color){180, 180, 180, 255};
    insert_object(functionName, functionManager);

    int nameLenght = -1;
    void updateFunctionName(input* data, int collision) {
        if (currentFunction == -1){
            set_text(functionName, (SDL_Color){120, 120, 120, 0}, arial, "(No function selected)");
        }
        else {
            if (collision) {
                functionName->border = (SDL_Color){120, 120, 120, 255};
                if (nameLenght == -1 && ((data->dleft && data->left) || data->enter)) {
                    nameLenght = 0;
                    functionName->border = (SDL_Color){120, 120, 120, 255};
                    sprintf(*(names + currentFunction), "[Insert new name]");
                }
                else if (nameLenght == 0 && ((data->dleft && data->left) || data->enter)) {
                        sprintf(*(names + currentFunction), "Function %i", data->obj->offset);
                    nameLenght = -1;
                }
            }
            if (nameLenght != -1 && data->enter) {
                if (nameLenght == 0)
                    sprintf(*(names + currentFunction), "Function %i", data->obj->offset);
                nameLenght = -1;
            }

            if (nameLenght != -1) {
                functionName->border = (SDL_Color){120, 120, 120, 255};
                if (data->key != '\0') {
                    sprintf(*(names + currentFunction) + nameLenght, "%c", data->key);
                    nameLenght++;
                }
                if (data->backspace) {
                    if (nameLenght > 0) {
                        *(*(names + currentFunction) + nameLenght) = 0;
                        nameLenght--;
                    }
                    else {
                        **(names + currentFunction) = '-';
                        *(*(names + currentFunction) + 1) = 0;
                        nameLenght = 0;
                    }
                }
            }
            else if (!collision)
                functionName->border = (SDL_Color){0, 0, 0, 0};
            set_text(functionName, (SDL_Color){120, 120, 120, 0}, arial, *(names + currentFunction));
        }
    }
    functionName->update = updateFunctionName;

    object* functionExpr = malloc_object();
    functionExpr->background = (SDL_Color){170, 170, 170, 255};
    insert_object(functionExpr, functionManager);

    int exprLengt = -1;
    void updateFunctionExpr(input* data, int collision) {
        if (currentFunction == -1)
            functionExpr->rect = (SDL_Rect){0, 50, 0, 0};
        else {
            functionExpr->rect = (SDL_Rect){0, 50, functionManager->rect.w/2, 20};
            if (collision) {
                functionExpr->border = (SDL_Color){120, 120, 120, 255};
                if (exprLengt == -1 && ((data->dleft && data->left) || data->enter)) {
                    exprLengt = 0;
                    sprintf(*(functionsExpr + currentFunction), "x");
                }
                else if (exprLengt == 0 && ((data->dleft && data->left) || data->enter)) {
                        sprintf(*(functionsExpr + currentFunction), "Function %i", data->obj->offset);
                    exprLengt = -1;
                }
            }
            else {
                functionExpr->border = (SDL_Color){0, 0, 0, 0};
                if (exprLengt != -1) {
                    exprLengt = -1;
                }
            }

            if (exprLengt != -1) {
                if (data->key != '\0') {
                    sprintf(*(functionsExpr + currentFunction) + exprLengt, "%c", data->key);
                    exprLengt++;
                }
                if (data->backspace) {
                    if (exprLengt > 0) {
                        *(*(functionsExpr + currentFunction) + exprLengt) = 0;
                        exprLengt--;
                    }
                    else {
                        **(functionsExpr + currentFunction) = '0';
                        *(*(functionsExpr + currentFunction) + 1) = 0;
                        exprLengt = 0;
                    }
                }
            }

            set_text(functionExpr, (SDL_Color){120, 120, 120, 0}, arial, functionsExpr[currentFunction]);
        }
    }
    functionExpr->update = updateFunctionExpr;

    object* functionColor = malloc_object();
    functionColor->background = (SDL_Color){80, 80, 220, 255};
    insert_object(functionColor, functionManager);

    void updateFunctionColor() {
        if (currentFunction == -1)
            functionColor->rect = (SDL_Rect){0, 75, 0, 0};
        else {
            functionColor->rect = (SDL_Rect){0, 75, 20, 20};
            functionColor->background = pixels[currentFunction*graphArea->rect.w]->background;
        }
    }
    functionColor->update = updateFunctionColor;

    object* redColor = malloc_object();
    redColor->background = (SDL_Color){170, 170, 170, 255};
    insert_object(redColor, functionManager);

    int redDigit = 0;
    char redValue[4] = "80";
    void updateRedColor(input* data, int collision) {
        if (currentFunction == -1)
            redColor->rect = (SDL_Rect){0, 75, 0, 0};
        else {
            redColor->rect = (SDL_Rect){25, 75, 60, 20};
            if (collision) {
                redColor->border = (SDL_Color){120, 120, 120, 255};
                if (data->key != '\0' && redDigit < 3) {
                    redValue[redDigit] = data->key;
                    redDigit++;
                    redValue[redDigit] = 0;
                }
                if (data->backspace) {
                    if (redDigit > 1) {
                        redDigit--;
                        redValue[redDigit] = 0;
                    }
                    else {
                        redValue[0] = '0';
                        redValue[1] = 0;
                        redDigit = 0;
                    }
                }
                if (data->enter) {
                    for (int i = 0; i < graphArea->rect.w; i++)
                        pixels[currentFunction*graphArea->rect.w+i]->background.r = atoi(redValue);
                }
            }
            else {
                redColor->border = (SDL_Color){0, 0, 0, 0};
            }
            set_text(redColor, (SDL_Color){120, 120, 120, 0}, arial, redValue);
        }
    }
    redColor->update = updateRedColor;

    object* greenColor = malloc_object();
    greenColor->background = (SDL_Color){170, 170, 170, 255};
    insert_object(greenColor, functionManager);

    int greenDigit = 0;
    char greenValue[4] = "80";
    void updateGreenColor(input* data, int collision) {
        if (currentFunction == -1)
            greenColor->rect = (SDL_Rect){0, 75, 0, 0};
        else {
            greenColor->rect = (SDL_Rect){90, 75, 60, 20};
            if (collision) {
                greenColor->border = (SDL_Color){120, 120, 120, 255};
                if (data->key != '\0' && greenDigit < 3) {
                    greenValue[greenDigit] = data->key;
                    greenDigit++;
                    greenValue[greenDigit] = 0;
                }
                if (data->backspace) {
                    if (greenDigit > 1) {
                        greenDigit--;
                        greenValue[greenDigit] = 0;
                    }
                    else {
                        greenValue[0] = '0';
                        greenValue[1] = 0;
                        greenDigit = 0;
                    }
                }
                if (data->enter) {
                    for (int i = 0; i < graphArea->rect.w; i++)
                        pixels[currentFunction*graphArea->rect.w+i]->background.g = atoi(greenValue);
                }
            }
            else {
                greenColor->border = (SDL_Color){0, 0, 0, 0};
            }
            set_text(greenColor, (SDL_Color){120, 120, 120, 0}, arial, greenValue);
        }
    }
    greenColor->update = updateGreenColor;

    object* blueColor = malloc_object();
    blueColor->background = (SDL_Color){170, 170, 170, 255};
    insert_object(blueColor, functionManager);

    int blueDigit = 0;
    char blueValue[4] = "180";
    void updateBlueColor(input* data, int collision) {
        if (currentFunction == -1)
            blueColor->rect = (SDL_Rect){0, 75, 0, 0};
        else {
            blueColor->rect = (SDL_Rect){155, 75, 60, 20};
            if (collision) {
                blueColor->border = (SDL_Color){120, 120, 120, 255};
                if (data->key != '\0' && blueDigit < 3) {
                    blueValue[blueDigit] = data->key;
                    blueDigit++;
                    blueValue[blueDigit] = 0;
                }
                if (data->backspace) {
                    if (blueDigit > 1) {
                        blueDigit--;
                        blueValue[blueDigit] = 0;
                    }
                    else {
                        blueValue[0] = '0';
                        blueValue[1] = 0;
                        blueDigit = 0;
                    }
                }
                if (data->enter) {
                    for (int i = 0; i < graphArea->rect.w; i++)
                        pixels[currentFunction*graphArea->rect.w+i]->background.b = atoi(blueValue);
                }
            }
            else {
                blueColor->border = (SDL_Color){0, 0, 0, 0};
            }
            set_text(blueColor, (SDL_Color){120, 120, 120, 0}, arial, blueValue);
        }
    }
    blueColor->update = updateBlueColor;

    object* functionStateDisplay = malloc_object();
    functionStateDisplay->background = (SDL_Color){170, 170, 170, 255};
    insert_object(functionStateDisplay, functionManager);
    
    void updateFunctionStateDisplay(input* data, int collision) {
        if (currentFunction == -1) {
            functionStateDisplay->rect = (SDL_Rect){functionManager->rect.w - 80, 0, 0, 0};
        }
        else {
            functionStateDisplay->rect = (SDL_Rect){functionManager->rect.w - 80, 0, 80, 20};
            set_text(functionStateDisplay, (SDL_Color){120, 120, 120, 0}, arial, (functionState[currentFunction] ? "Hide" : "Show"));
            if (collision) {
                functionStateDisplay->border = (SDL_Color){120, 120, 120, 255};
                if (data->dleft && data->left)
                    functionState[currentFunction] = !functionState[currentFunction];
            }
            else
                functionStateDisplay->border = (SDL_Color){0, 0, 0, 0};
        }
    }
    functionStateDisplay->update = updateFunctionStateDisplay;

    void updateFunctionButton(input* data, int collision) {
            if (data->obj->offset < functionsCount) {
                data->obj->rect = (SDL_Rect){5, 20+(data->obj->offset+1)*25, functionSelector->rect.w - 35, 20};
                set_text(data->obj, (SDL_Color){120, 120, 120, 0}, arial, *(names + data->obj->offset));
            }
            else
                data->obj->rect = (SDL_Rect){-200, 20+(data->obj->offset+1)*25, 160, 20};
            
            if (collision) {
                data->obj->border = (SDL_Color){120, 120, 120, 255};
                if (data->dleft && data->left) {
                    functionSelector->rect = (SDL_Rect){0, 0, 0, 0};
                    currentFunction = data->obj->offset;
                }
            }
            else
                data->obj->border = (SDL_Color){0, 0, 0, 0};
        }

    for (int i = 0; i < maxFunctions; i++) {
        functionState[i] = 1;
        functions[i] = malloc_object();
        functions[i]->offset = i;
        functions[i]->background = (SDL_Color){170, 170, 170, 255};
        functions[i]->update = updateFunctionButton;
        insert_object(functions[i], functionSelector);
    }

    object* functionSelectorScroll = malloc_object();
    insert_object(functionSelectorScroll, functionSelector);

    void updateFunctionSelectorScroll(input* data, int collision) {
        functionSelectorScroll->rect.x = functionSelector->rect.w - 20;
        functionSelectorScroll->rect.w = 20;
        functionSelectorScroll->rect.h = 20;
        if (collision) {
            functionSelectorScroll->background = (SDL_Color){150, 150, 150, 255};
            if (data->left) {
                int dy = functionSelectorScroll->rect.y;
                functionSelectorScroll->rect.y = fmin(functionSelector->rect.h-20, fmax(functionSelectorScroll->rect.y + data->dy, 0));
                dy = functionSelectorScroll->rect.y - dy;
                functionSelectorScroll->rect.y += 4*dy;
                functionSelector->rect.y = fmin(0, fmax(functionSelector->rect.y - 4*dy, -functionSelector->rect.h+functionManager->rect.h));
            }
        }
        else {
            functionSelectorScroll->background = (SDL_Color){170, 170, 170, 255};
        }
    }
    functionSelectorScroll->update = updateFunctionSelectorScroll;
    

    object* newFunctionButton = malloc_object();
    newFunctionButton->background = (SDL_Color){60, 160, 60, 255};
    set_text(newFunctionButton, (SDL_Color){200, 200, 200, 0}, arial, "Add New Function");
    insert_object(newFunctionButton, functionSelector);

    void updateNewFuntionButton(input* data, int collision) {
        if (collision) {
            newFunctionButton->border = (SDL_Color){120, 120, 120, 255};
            if (data->dleft && data->left) {
                currentFunction = functionsCount;
                functionsCount++;
                sprintf(*(names + currentFunction), "Function %i", functionsCount);

                functionsExpr[currentFunction][0] = 'x';
                functionsExpr[currentFunction][1] = '\0';
                
                for (int i = 0; i < graphArea->rect.w; i++)
                    pixels[currentFunction*graphArea->rect.w+i]->background = (SDL_Color){80, 80, 180, 255};
                
                functionSelector->rect = (SDL_Rect){0, 0, 0, 0};
            }
        }
        else {
            newFunctionButton->border = (SDL_Color){0, 0, 0, 0};
        }
        newFunctionButton->rect = (SDL_Rect){(functionSelector->rect.w - 160)/2, 20, 160, 20};
    }
    newFunctionButton->update = updateNewFuntionButton;

    object* selectFunctionButton = malloc_object();
    selectFunctionButton->rect = (SDL_Rect){0, 0, 80, 20};
    selectFunctionButton->background = (SDL_Color){170, 170, 170, 255};
    set_text(selectFunctionButton, (SDL_Color){120, 120, 120, 0}, arial, "Select");
    insert_object(selectFunctionButton, functionManager);

    void updateSelectFunctionButton(input* data, int collision) {
        if (collision) {
            selectFunctionButton->border = (SDL_Color){120, 120, 120, 255};
            if (data->dleft && data->left) {
                currentFunction = -1;
                functionSelector->rect = (SDL_Rect){0, 0, functionManager->rect.w, 10*functionManager->rect.h};
                functionSelectorScroll->rect.y = 0;
            }
        }
        else
            selectFunctionButton->border = (SDL_Color){0, 0, 0, 0};
    }
    selectFunctionButton->update = updateSelectFunctionButton;

    object* deleteFunctionButton = malloc_object();
    deleteFunctionButton->background = (SDL_Color){200, 60, 60, 255};
    set_text(deleteFunctionButton, (SDL_Color){220, 220, 220, 0}, arial, "Delete");
    insert_object(deleteFunctionButton, functionManager);

    void updateDeleteFunctionButton(input* data, int collision) {
        if (currentFunction == -1) {
            deleteFunctionButton->rect = (SDL_Rect){90, 0, 0, 0};
        }
        else {
            deleteFunctionButton->rect = (SDL_Rect){90, 0, 80, 20};
            if (collision) {
                deleteFunctionButton->border = (SDL_Color){200, 200, 200, 255};
                if (data->dleft && data->left) {
                    for (int i = 0; i < graphArea->rect.w; i++) {
                        pixels[currentFunction*graphArea->rect.w+i]->rect = (SDL_Rect){0, 0, 0, 0};
                    }
                    for (int i = currentFunction; i < functionsCount-1; i++) {
                        functionState[i] = functionState[i+1];
                        int j = 0;
                        while (names[i+1][j] != 0) {
                            names[i][j] = names[i+1][j];
                            j++;
                        }
                        names[i][j] = 0;
                        for (int j = 0; j < graphArea->rect.w; j++) {
                            pixels[i*graphArea->rect.w+j] = pixels[(i+1)*graphArea->rect.w+j];
                        }
                    }
                    functionsCount--;
                    currentFunction = -1;
                }
            }
            else
                deleteFunctionButton->border = (SDL_Color){0, 0, 0, 0};
        }
    }
    deleteFunctionButton->update = updateDeleteFunctionButton;
    

    // python ------------------------------------------------------------------
    object* addProgram = malloc_object();
    addProgram->rect = (SDL_Rect){width/2 - 70, 40, 140, 20};
    addProgram->background = (SDL_Color){50, 170, 50, 255};
    set_text(addProgram, (SDL_Color){200, 200, 200, 0}, arial, "Add Program");
    insert_object(addProgram, python);

    object* runButton = malloc_object();
    runButton->rect = (SDL_Rect){width - 85, 65, 20, 20};
    runButton->background = (SDL_Color){170, 170, 170, 255};
    set_image(runButton, (SDL_Color){120, 120, 120, 0}, "assets/down.png");
    insert_object(runButton, python);

    void updateRunButton(input* data, int collision) {
        if (collision && data->dleft && data->left) {
            ker->root = pythonOutput;
            backButton->rect = (SDL_Rect){width - 80, 8, 60, 20};
            homeButton->rect = (SDL_Rect){(width - 30)/2, 3, 0, 0};
        }
    }
    runButton->update = updateRunButton;

    object* trashButton = malloc_object();
    trashButton->rect = (SDL_Rect){width - 60, 65, 20, 20};
    trashButton->background = (SDL_Color){170, 170, 170, 255};
    set_image(trashButton, (SDL_Color){180, 80, 80, 0}, "assets/trash.png");
    insert_object(trashButton, python);
    
    object* program = malloc_object();
    program->rect = (SDL_Rect){40, 65, width - 160, 20};
    program->background = (SDL_Color){170, 170, 170, 255};
    set_text(program, (SDL_Color){120, 120, 120, 0}, arial, "home/Epita/Prog/Project/test.py");
    insert_object(program, python);

    // polynomials -----------------------------------------------------------------
    double PxMin = -4.0;
    double PxMax = 4.0;
    double PyMin = -4.0;
    double PyMax = 4.0;
    double Pinterval = 1.0;

    int PmaxFunctions = 3;
    int PfunctionsCount = 0;
    int PcurrentFunction = -1;
    int PfunctionState[PmaxFunctions];
    char Pnames[PmaxFunctions][128];
    char PfunctionsExpr[PmaxFunctions][256];

    object* Pfunctions[PmaxFunctions];

    object* PgraphArea = malloc_object();
    PgraphArea->offset = 0;
    PgraphArea->rect = (SDL_Rect){0, 0, width, width};
    PgraphArea->background = (SDL_Color){200, 200, 200, 255};
    insert_object(PgraphArea, polynomials);

    object* PyAxis = malloc_object();
    PyAxis->offset = 1;
    PyAxis->rect = (SDL_Rect){0, 0, 1, PgraphArea->rect.w};
    PyAxis->background = (SDL_Color){80, 80, 80, 255};
    insert_object(PyAxis, PgraphArea);

    object* PxAxis = malloc_object();
    PxAxis->offset = 1;
    PxAxis->rect = (SDL_Rect){0, 0, PgraphArea->rect.w, 1};
    PxAxis->background = (SDL_Color){80, 80, 80, 255};
    insert_object(PxAxis, PgraphArea);

    int PmaxLines = 32;
    object* PyGrid[PmaxLines];
    object* PxGrid[PmaxLines];
    object* Ppixels[PgraphArea->rect.w*PmaxFunctions];

    void PupdateGrapher(input* data, int collision) {
        if (collision) {
            double xInterval = (PxMax - PxMin)/PgraphArea->rect.w;
            double yInterval = (PyMax - PyMin)/PgraphArea->rect.w;

            PxMax -= 20*((double)data->dwheel)*xInterval;
            //xMin += 20*((double)data->dwheel)*xInterval;
            PyMax -= 20*((double)data->dwheel)*yInterval;
            //yMin += 20*((double)data->dwheel)*yInterval;

            if (data->left) {
                PxMax -= ((double)data->dx)*xInterval;
                PxMin -= ((double)data->dx)*xInterval;
                PyMax += ((double)data->dy)*yInterval;
                PyMin += ((double)data->dy)*yInterval;
            }
            
            PyAxis->rect.x = -((int)((PxMin)/xInterval));
            PxAxis->rect.y = PgraphArea->rect.w+((int)((PyMin)/yInterval));

            if ((int)((PxMax-PxMin)/Pinterval)+1 > PmaxLines)
                Pinterval *= 10;
            else if ((int)((PxMax-PxMin)/Pinterval)+1 < 4)
                Pinterval /= 10;

            double offset = PxMin - (int)(PxMin/Pinterval)*Pinterval;
            int index = 0;
            for (double x = PxMin - offset; x <= PxMax; x += Pinterval) {
                PxGrid[index]->rect.x = (int)((x - PxMin)/xInterval);
                index++;
            }
            for (int i = index; i < PmaxLines; i++)
                PxGrid[i]->rect.x = -1;

            offset = PyMin - (int)(PyMin/Pinterval)*Pinterval;
            index = 0;
            for (double y = PyMin - offset; y <= PyMax; y += Pinterval) {
                PyGrid[index]->rect.y = PgraphArea->rect.w - (int)((y - PyMin)/yInterval);
                index++;
            }
            for (int i = index; i < PmaxLines; i++)
                PyGrid[i]->rect.y = -1;

            int k = -1;
            int step = 2;
            for (int i = 0; i < PgraphArea->rect.w*PmaxFunctions; i += step) {
                int xPos = i % PgraphArea->rect.w;
                k += xPos == 0;

                if (k < PfunctionsCount && PfunctionState[k]) {
                    double x = PxMin + xPos * xInterval;

                    int size = snprintf(NULL, 0, "%f", x);  // Obtenir la taille réelle requise
                    char* buffer = malloc(size + 1);  // Allouer l'espace nécessaire
                    snprintf(buffer, size + 1, "%f", x);  // Convertir le double en chaîne

                    size_t length = strlen(PfunctionsExpr[k]);
                    char* result = malloc(length + 1);  // Allouer l'espace pour la nouvelle chaîne

                    // Copier la chaîne d'origine dans la nouvelle chaîne
                    
                    strncpy(result, PfunctionsExpr[k], length + 1);

                    char* pos = strchr(result, 'x');
                    while (pos != NULL) {
                        // Remplacement de 'x' par la chaîne représentant le double
                        memmove(pos + size, pos + 1, strlen(pos + 1) + 1);
                        memcpy(pos, buffer, size);

                        pos = strchr(pos + size, 'x');
                    }

                    free(buffer);  // Libérer la mémoire allouée

                    //printf("%s\n", PfunctionsExpr[k]);
                    struct poly* P = build_poly(PfunctionsExpr[k]);
                    double y = evaluate(P, x);
                    //printf("f(%f) = %f\n", x, y);

                    /*
                    int len = 0; 
                    int len_rpn = 0;
                    struct Token_Type** res = lexer(result,&len);
                    struct Token_Type** rpn = RPN(res,len,&len_rpn);
                    struct Tree* tree = Build_Tree(rpn,len_rpn);
                    double y = computeTree(tree);
                    */
                    
                    int j = (int)((y - PyMin)/yInterval);
                    if (j >= 0 && j <= PgraphArea->rect.w) {
                        Ppixels[i]->rect = (SDL_Rect){xPos, PgraphArea->rect.w-1-j, 2, 2};
                        if (xPos > 0 && abs(Ppixels[i-step]->rect.y - Ppixels[i]->rect.y) >= 1) {
                            int diff = abs(Ppixels[i-step]->rect.y - Ppixels[i]->rect.y);
                            Ppixels[i]->rect.h = diff;
                        }
                    }
                    else
                        Ppixels[i]->rect = (SDL_Rect){0, 0, 0, 0};
                }
                else
                    Ppixels[i]->rect = (SDL_Rect){0, 0, 0, 0};
            }

        }
    }
    PgraphArea->update = PupdateGrapher;
    PxAxis->update = PupdateGrapher;
    PyAxis->update = PupdateGrapher;

    for (int i = 0; i < PgraphArea->rect.w*PmaxFunctions; i++) {
        Ppixels[i] = malloc_object();
        Ppixels[i]->offset = 2;
        Ppixels[i]->background = (SDL_Color){0, 0, 0, 0};
        Ppixels[i]->update = PupdateGrapher;
        insert_object(Ppixels[i], PgraphArea);
    }

    for (int i = 0; i < PmaxLines; i++) {
        PyGrid[i] = malloc_object();
        PyGrid[i]->offset = 1;
        PyGrid[i]->rect = (SDL_Rect){0, 0, PgraphArea->rect.w, 1};
        PyGrid[i]->background = (SDL_Color){180, 180, 180, 255};
        PyGrid[i]->update = PupdateGrapher;

        PxGrid[i] = malloc_object();
        PxGrid[i]->offset = 1;
        PxGrid[i]->rect = (SDL_Rect){0, 0, 1, PgraphArea->rect.w};
        PxGrid[i]->background = (SDL_Color){180, 180, 180, 255};
        PxGrid[i]->update = PupdateGrapher;

        insert_object(PyGrid[i], PgraphArea);
        insert_object(PxGrid[i], PgraphArea);
    }

    object* PfunctionManager = malloc_object();
    PfunctionManager->rect = (SDL_Rect){10, width + 10, width - 20, height - width - 56};
    PfunctionManager->background = (SDL_Color){180, 180, 180, 255};
    insert_object(PfunctionManager, polynomials);

    object* PfunctionSelector = malloc_object();
    PfunctionSelector->offset = 2;
    PfunctionSelector->background = (SDL_Color){180, 180, 180, 255};
    insert_object(PfunctionSelector, PfunctionManager);

    object* solutionLabel = malloc_object();
    solutionLabel->rect = (SDL_Rect){width/2 + 20, 50, width/2 - 40, 20};
    solutionLabel->background = (SDL_Color){170, 170, 170, 255};
    insert_object(solutionLabel, PfunctionManager);

    object* PfunctionName = malloc_object();
    PfunctionName->rect = (SDL_Rect){0, 25, PfunctionManager->rect.w, 20};
    PfunctionName->background = (SDL_Color){180, 180, 180, 255};
    insert_object(PfunctionName, PfunctionManager);

    int PnameLenght = -1;
    void PupdateFunctionName(input* data, int collision) {
        if (PcurrentFunction == -1){
            set_text(PfunctionName, (SDL_Color){120, 120, 120, 0}, arial, "(No function selected)");
        }
        else {
            if (collision) {
                PfunctionName->border = (SDL_Color){120, 120, 120, 255};
                if (PnameLenght == -1 && ((data->dleft && data->left) || data->enter)) {
                    PnameLenght = 0;
                    PfunctionName->border = (SDL_Color){120, 120, 120, 255};
                    sprintf(*(Pnames + PcurrentFunction), "[Insert new name]");
                }
                else if (PnameLenght == 0 && ((data->dleft && data->left) || data->enter)) {
                        sprintf(*(Pnames + PcurrentFunction), "Function %i", data->obj->offset);
                    PnameLenght = -1;
                }
            }
            if (PnameLenght != -1 && data->enter) {
                if (PnameLenght == 0)
                    sprintf(*(Pnames + PcurrentFunction), "Function %i", data->obj->offset);
                PnameLenght = -1;
            }

            if (PnameLenght != -1) {
                PfunctionName->border = (SDL_Color){120, 120, 120, 255};
                if (data->key != '\0') {
                    sprintf(*(Pnames + PcurrentFunction) + PnameLenght, "%c", data->key);
                    PnameLenght++;
                }
                if (data->backspace) {
                    if (PnameLenght > 0) {
                        *(*(Pnames + PcurrentFunction) + PnameLenght) = 0;
                        PnameLenght--;
                    }
                    else {
                        **(Pnames + PcurrentFunction) = '-';
                        *(*(Pnames + PcurrentFunction) + 1) = 0;
                        PnameLenght = 0;
                    }
                }
            }
            else if (!collision)
                PfunctionName->border = (SDL_Color){0, 0, 0, 0};
            set_text(PfunctionName, (SDL_Color){120, 120, 120, 0}, arial, *(Pnames + PcurrentFunction));
        }
    }
    PfunctionName->update = PupdateFunctionName;

    object* PfunctionExpr = malloc_object();
    PfunctionExpr->background = (SDL_Color){170, 170, 170, 255};
    insert_object(PfunctionExpr, PfunctionManager);

    int PexprLengt = -1;
    void PupdateFunctionExpr(input* data, int collision) {
        if (PcurrentFunction == -1)
            PfunctionExpr->rect = (SDL_Rect){0, 50, 0, 0};
        else {
            PfunctionExpr->rect = (SDL_Rect){0, 50, PfunctionManager->rect.w/2, 20};
            if (collision) {
                PfunctionExpr->border = (SDL_Color){120, 120, 120, 255};
                if (PexprLengt == -1 && ((data->dleft && data->left) || data->enter)) {
                    PexprLengt = 0;
                    sprintf(*(PfunctionsExpr + PcurrentFunction), "x");
                }
                else if (PexprLengt == 0 && ((data->dleft && data->left) || data->enter)) {
                        sprintf(*(PfunctionsExpr + PcurrentFunction), "x");
                    PexprLengt = -1;
                }
            }
            else {
                PfunctionExpr->border = (SDL_Color){0, 0, 0, 0};
                if (PexprLengt != -1) {
                    PexprLengt = -1;
                }
            }

            if (PexprLengt != -1) {
                if (data->key != '\0') {
                    sprintf(*(PfunctionsExpr + PcurrentFunction) + PexprLengt, "%c", data->key);
                    PexprLengt++;
                }
                if (data->backspace) {
                    if (PexprLengt > 0) {
                        *(*(PfunctionsExpr + PcurrentFunction) + PexprLengt) = 0;
                        PexprLengt--;
                    }
                    else {
                        **(PfunctionsExpr + PcurrentFunction) = '0';
                        *(*(PfunctionsExpr + PcurrentFunction) + 1) = 0;
                        PexprLengt = 0;
                    }
                }
            }

            set_text(PfunctionExpr, (SDL_Color){120, 120, 120, 0}, arial, PfunctionsExpr[PcurrentFunction]);
        }
    }
    PfunctionExpr->update = PupdateFunctionExpr;

    int currentSolution = 0;
    int maxSolutions = 3;
    void updateSolutions(input* data, int collision) {
        if (PcurrentFunction == -1) {
            solutionLabel->rect = (SDL_Rect){width/2 + 20, 50, 0, 0};
        }
        else if (PexprLengt == -1) {
            solutionLabel->rect = (SDL_Rect){width/2 + 20, 50, width/2 - 40, 20};

            struct poly* P = build_poly(PfunctionsExpr[PcurrentFunction]);
            struct solution* S = solve(P);

            maxSolutions = 0;
            struct solution* cpy = S;
            while (cpy !=NULL ){
                cpy = cpy->next;
                maxSolutions++;
            }

            if (collision) {
                solutionLabel->border = (SDL_Color){120, 120, 120, 255};
                if (data->dleft && data->left && maxSolutions > 0)
                    currentSolution = (currentSolution + 1) % maxSolutions;
            }
            else
                solutionLabel->border = (SDL_Color){0, 0, 0, 0};

            double x0;
            int cpt = 0;
            while (S != NULL) {
                if (cpt == currentSolution)
                    x0 = S->value;
                S = S->next;
                cpt++;
            }

            char solution[64];
            if (maxSolutions > 0)
                snprintf(solution, 64, "x%i = %f", currentSolution, x0);
            else
                snprintf(solution, 64, "no solutions");
            set_text(solutionLabel, (SDL_Color){120, 120, 120, 0}, arial, solution);
        }
    }
    solutionLabel->update = updateSolutions;

    object* PfunctionColor = malloc_object();
    PfunctionColor->background = (SDL_Color){80, 80, 220, 255};
    insert_object(PfunctionColor, PfunctionManager);

    void PupdateFunctionColor() {
        if (PcurrentFunction == -1)
            PfunctionColor->rect = (SDL_Rect){0, 75, 0, 0};
        else {
            PfunctionColor->rect = (SDL_Rect){0, 75, 20, 20};
            PfunctionColor->background = Ppixels[PcurrentFunction*PgraphArea->rect.w]->background;
        }
    }
    PfunctionColor->update = PupdateFunctionColor;

    object* PredColor = malloc_object();
    PredColor->background = (SDL_Color){170, 170, 170, 255};
    insert_object(PredColor, PfunctionManager);

    int PredDigit = 0;
    char PredValue[4] = "80";
    void PupdateRedColor(input* data, int collision) {
        if (PcurrentFunction == -1)
            PredColor->rect = (SDL_Rect){0, 75, 0, 0};
        else {
            PredColor->rect = (SDL_Rect){25, 75, 60, 20};
            if (collision) {
                PredColor->border = (SDL_Color){120, 120, 120, 255};
                if (data->key != '\0' && PredDigit < 3) {
                    PredValue[PredDigit] = data->key;
                    PredDigit++;
                    PredValue[PredDigit] = 0;
                }
                if (data->backspace) {
                    if (PredDigit > 1) {
                        PredDigit--;
                        PredValue[PredDigit] = 0;
                    }
                    else {
                        PredValue[0] = '0';
                        PredValue[1] = 0;
                        PredDigit = 0;
                    }
                }
                if (data->enter) {
                    for (int i = 0; i < PgraphArea->rect.w; i++)
                        Ppixels[PcurrentFunction*PgraphArea->rect.w+i]->background.r = atoi(PredValue);
                }
            }
            else {
                PredColor->border = (SDL_Color){0, 0, 0, 0};
            }
            set_text(PredColor, (SDL_Color){120, 120, 120, 0}, arial, PredValue);
        }
    }
    PredColor->update = PupdateRedColor;

    object* PgreenColor = malloc_object();
    PgreenColor->background = (SDL_Color){170, 170, 170, 255};
    insert_object(PgreenColor, PfunctionManager);

    int PgreenDigit = 0;
    char PgreenValue[4] = "80";
    void PupdateGreenColor(input* data, int collision) {
        if (PcurrentFunction == -1)
            PgreenColor->rect = (SDL_Rect){0, 75, 0, 0};
        else {
            PgreenColor->rect = (SDL_Rect){90, 75, 60, 20};
            if (collision) {
                PgreenColor->border = (SDL_Color){120, 120, 120, 255};
                if (data->key != '\0' && PgreenDigit < 3) {
                    PgreenValue[PgreenDigit] = data->key;
                    PgreenDigit++;
                    PgreenValue[PgreenDigit] = 0;
                }
                if (data->backspace) {
                    if (PgreenDigit > 1) {
                        PgreenDigit--;
                        PgreenValue[PgreenDigit] = 0;
                    }
                    else {
                        PgreenValue[0] = '0';
                        PgreenValue[1] = 0;
                        PgreenDigit = 0;
                    }
                }
                if (data->enter) {
                    for (int i = 0; i < PgraphArea->rect.w; i++)
                        Ppixels[PcurrentFunction*PgraphArea->rect.w+i]->background.g = atoi(PgreenValue);
                }
            }
            else {
                PgreenColor->border = (SDL_Color){0, 0, 0, 0};
            }
            set_text(PgreenColor, (SDL_Color){120, 120, 120, 0}, arial, PgreenValue);
        }
    }
    PgreenColor->update = PupdateGreenColor;

    object* PblueColor = malloc_object();
    PblueColor->background = (SDL_Color){170, 170, 170, 255};
    insert_object(PblueColor, PfunctionManager);

    int PblueDigit = 0;
    char PblueValue[4] = "180";
    void PupdateBlueColor(input* data, int collision) {
        if (PcurrentFunction == -1)
            PblueColor->rect = (SDL_Rect){0, 75, 0, 0};
        else {
            PblueColor->rect = (SDL_Rect){155, 75, 60, 20};
            if (collision) {
                PblueColor->border = (SDL_Color){120, 120, 120, 255};
                if (data->key != '\0' && PblueDigit < 3) {
                    PblueValue[PblueDigit] = data->key;
                    PblueDigit++;
                    PblueValue[PblueDigit] = 0;
                }
                if (data->backspace) {
                    if (PblueDigit > 1) {
                        PblueDigit--;
                        PblueValue[PblueDigit] = 0;
                    }
                    else {
                        PblueValue[0] = '0';
                        PblueValue[1] = 0;
                        PblueDigit = 0;
                    }
                }
                if (data->enter) {
                    for (int i = 0; i < PgraphArea->rect.w; i++)
                        Ppixels[PcurrentFunction*PgraphArea->rect.w+i]->background.b = atoi(PblueValue);
                }
            }
            else {
                PblueColor->border = (SDL_Color){0, 0, 0, 0};
            }
            set_text(PblueColor, (SDL_Color){120, 120, 120, 0}, arial, PblueValue);
        }
    }
    PblueColor->update = PupdateBlueColor;

    object* PfunctionStateDisplay = malloc_object();
    PfunctionStateDisplay->background = (SDL_Color){170, 170, 170, 255};
    insert_object(PfunctionStateDisplay, PfunctionManager);
    
    void PupdateFunctionStateDisplay(input* data, int collision) {
        if (PcurrentFunction == -1) {
            PfunctionStateDisplay->rect = (SDL_Rect){PfunctionManager->rect.w - 80, 0, 0, 0};
        }
        else {
            PfunctionStateDisplay->rect = (SDL_Rect){PfunctionManager->rect.w - 80, 0, 80, 20};
            set_text(PfunctionStateDisplay, (SDL_Color){120, 120, 120, 0}, arial, (PfunctionState[PcurrentFunction] ? "Hide" : "Show"));
            if (collision) {
                PfunctionStateDisplay->border = (SDL_Color){120, 120, 120, 255};
                if (data->dleft && data->left)
                    PfunctionState[PcurrentFunction] = !PfunctionState[PcurrentFunction];
            }
            else
                PfunctionStateDisplay->border = (SDL_Color){0, 0, 0, 0};
        }
    }
    PfunctionStateDisplay->update = PupdateFunctionStateDisplay;

    void PupdateFunctionButton(input* data, int collision) {
            if (data->obj->offset < PfunctionsCount) {
                data->obj->rect = (SDL_Rect){5, 20+(data->obj->offset+1)*25, PfunctionSelector->rect.w - 35, 20};
                set_text(data->obj, (SDL_Color){120, 120, 120, 0}, arial, *(Pnames + data->obj->offset));
            }
            else
                data->obj->rect = (SDL_Rect){-200, 20+(data->obj->offset+1)*25, 160, 20};
            
            if (collision) {
                data->obj->border = (SDL_Color){120, 120, 120, 255};
                if (data->dleft && data->left) {
                    PfunctionSelector->rect = (SDL_Rect){0, 0, 0, 0};
                    PcurrentFunction = data->obj->offset;
                }
            }
            else
                data->obj->border = (SDL_Color){0, 0, 0, 0};
        }

    for (int i = 0; i < PmaxFunctions; i++) {
        PfunctionState[i] = 1;
        Pfunctions[i] = malloc_object();
        Pfunctions[i]->offset = i;
        Pfunctions[i]->background = (SDL_Color){170, 170, 170, 255};
        Pfunctions[i]->update = PupdateFunctionButton;
        insert_object(Pfunctions[i], PfunctionSelector);
    }

    object* PfunctionSelectorScroll = malloc_object();
    insert_object(PfunctionSelectorScroll, PfunctionSelector);

    void PupdateFunctionSelectorScroll(input* data, int collision) {
        PfunctionSelectorScroll->rect.x = PfunctionSelector->rect.w - 20;
        PfunctionSelectorScroll->rect.w = 20;
        PfunctionSelectorScroll->rect.h = 20;
        if (collision) {
            PfunctionSelectorScroll->background = (SDL_Color){150, 150, 150, 255};
            if (data->left) {
                int dy = PfunctionSelectorScroll->rect.y;
                PfunctionSelectorScroll->rect.y = fmin(PfunctionSelector->rect.h-20, fmax(PfunctionSelectorScroll->rect.y + data->dy, 0));
                dy = PfunctionSelectorScroll->rect.y - dy;
                PfunctionSelectorScroll->rect.y += 4*dy;
                PfunctionSelector->rect.y = fmin(0, fmax(PfunctionSelector->rect.y - 4*dy, -PfunctionSelector->rect.h+PfunctionManager->rect.h));
            }
        }
        else {
            PfunctionSelectorScroll->background = (SDL_Color){170, 170, 170, 255};
        }
    }
    PfunctionSelectorScroll->update = PupdateFunctionSelectorScroll;
    

    object* PnewFunctionButton = malloc_object();
    PnewFunctionButton->background = (SDL_Color){60, 160, 60, 255};
    set_text(PnewFunctionButton, (SDL_Color){200, 200, 200, 0}, arial, "Add New Function");
    insert_object(PnewFunctionButton, PfunctionSelector);

    void PupdateNewFuntionButton(input* data, int collision) {
        if (collision) {
            PnewFunctionButton->border = (SDL_Color){120, 120, 120, 255};
            if (data->dleft && data->left) {
                PcurrentFunction = PfunctionsCount;
                PfunctionsCount++;
                sprintf(*(Pnames + PcurrentFunction), "Function %i", PfunctionsCount);

                PfunctionsExpr[PcurrentFunction][0] = 'x';
                PfunctionsExpr[PcurrentFunction][1] = '\0';
                
                for (int i = 0; i < PgraphArea->rect.w; i++)
                    Ppixels[PcurrentFunction*PgraphArea->rect.w+i]->background = (SDL_Color){80, 80, 180, 255};
                
                PfunctionSelector->rect = (SDL_Rect){0, 0, 0, 0};
            }
        }
        else {
            PnewFunctionButton->border = (SDL_Color){0, 0, 0, 0};
        }
        PnewFunctionButton->rect = (SDL_Rect){(PfunctionSelector->rect.w - 160)/2, 20, 160, 20};
    }
    PnewFunctionButton->update = PupdateNewFuntionButton;

    object* PselectFunctionButton = malloc_object();
    PselectFunctionButton->rect = (SDL_Rect){0, 0, 80, 20};
    PselectFunctionButton->background = (SDL_Color){170, 170, 170, 255};
    set_text(PselectFunctionButton, (SDL_Color){120, 120, 120, 0}, arial, "Select");
    insert_object(PselectFunctionButton, PfunctionManager);

    void PupdateSelectFunctionButton(input* data, int collision) {
        if (collision) {
            PselectFunctionButton->border = (SDL_Color){120, 120, 120, 255};
            if (data->dleft && data->left) {
                PcurrentFunction = -1;
                PfunctionSelector->rect = (SDL_Rect){0, 0, PfunctionManager->rect.w, 10*PfunctionManager->rect.h};
                PfunctionSelectorScroll->rect.y = 0;
            }
        }
        else
            PselectFunctionButton->border = (SDL_Color){0, 0, 0, 0};
    }
    PselectFunctionButton->update = PupdateSelectFunctionButton;

    object* PdeleteFunctionButton = malloc_object();
    PdeleteFunctionButton->background = (SDL_Color){200, 60, 60, 255};
    set_text(PdeleteFunctionButton, (SDL_Color){220, 220, 220, 0}, arial, "Delete");
    insert_object(PdeleteFunctionButton, PfunctionManager);

    void PupdateDeleteFunctionButton(input* data, int collision) {
        if (PcurrentFunction == -1) {
            PdeleteFunctionButton->rect = (SDL_Rect){90, 0, 0, 0};
        }
        else {
            PdeleteFunctionButton->rect = (SDL_Rect){90, 0, 80, 20};
            if (collision) {
                PdeleteFunctionButton->border = (SDL_Color){200, 200, 200, 255};
                if (data->dleft && data->left) {
                    for (int i = 0; i < PgraphArea->rect.w; i++) {
                        Ppixels[PcurrentFunction*PgraphArea->rect.w+i]->rect = (SDL_Rect){0, 0, 0, 0};
                    }
                    for (int i = PcurrentFunction; i < PfunctionsCount-1; i++) {
                        PfunctionState[i] = PfunctionState[i+1];
                        int j = 0;
                        while (Pnames[i+1][j] != 0) {
                            Pnames[i][j] = Pnames[i+1][j];
                            j++;
                        }
                        Pnames[i][j] = 0;
                        for (int j = 0; j < PgraphArea->rect.w; j++) {
                            Ppixels[i*PgraphArea->rect.w+j] = Ppixels[(i+1)*PgraphArea->rect.w+j];
                        }
                    }
                    PfunctionsCount--;
                    PcurrentFunction = -1;
                }
            }
            else
                PdeleteFunctionButton->border = (SDL_Color){0, 0, 0, 0};
        }
    }
    PdeleteFunctionButton->update = PupdateDeleteFunctionButton;

    run_kernel(ker);
    free_kernel(ker);

    return 0;
}