#include <stdio.h>
#include <stdlib.h>
#include "memory.h"

int main() {
  // Tester la fonction write_in_file
  write_in_file("Ceci est un test pour la fonction write_in_file");
  write_in_file("baaaaaaaaka");
  write_in_file("ceci est un rickroll");
  
  // Tester la fonction read_in_file
    char** lines = read_in_file(3);
    for (int i = 0; i < 3; i++){
	printf("Line %d: %s", i+1, lines[i]);
    }

    for (int i = 0; i < 3; i++) {
        free(lines[i]);
    }
    free(lines);

  // Tester la fonction write_stack
  struct Stack *head = NULL;
  write_stack(&head, 1);
  write_stack(&head, 2);
  write_stack(&head, 3);

  // Tester la fonction read_stack
  int data;
  while ((data = read_stack(&head)) != -1) {
    printf("Data: %d\n", data);
  }
  
  return 0;
}
