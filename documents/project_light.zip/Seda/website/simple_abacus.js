function demo_abac(exp){
    exp.array.forEach(element => {
        console.log(alement);
    });
}
