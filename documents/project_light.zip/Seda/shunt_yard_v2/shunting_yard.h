#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <err.h>

struct Token_Type
{
    struct Token_Operators* operator;
    struct Token_Operands* operands;
    struct Token_Parenthese* paranthese;
};
struct Token_Operators
{
    int operation_type;
    int precedence;
    int associativity;
    int nb_operands;
};
struct Token_Operands
{
    double value; //double
};
struct Token_Parenthese
{
    char is_left;
    char is_right;
};

struct Stack2 {
    int top;
    int capacity;
    struct Tree** array;
};

struct Node {
    struct Token_Type* data;
    struct Node* next;
};

struct Queue {
    struct Node* front; //fisrt out
    struct Node* rear; //first in
};

struct Stack {
    int top;
    int capacity;
    struct Token_Type** array;
};

struct Tree {
    struct Token_Type* data;
    struct Tree* left;
    struct Tree* right;
};

double computeTree(struct Tree* tree);
struct Token_Type* Create_Plus_Token();
struct Token_Type* Create_Minus_Token();
struct Token_Type* Create_Mult_Token();
struct Token_Type* Create_Div_Token();
struct Token_Type* Create_Mod_Token();
struct Token_Type* Create_Pow_Token();
struct Token_Type* Create_Number_Token(double value);
struct Token_Type* Create_Parenthese_Token(int left);
struct Token_Type** lexer(char* s, int* len);
int input_is_empty(char* input);
int is_number(char* str);
int contain_number(char* str);
double get_numerical_value(char* str);
int is_function(char* str);
int is_left_associative(char* str);
char get_priority(char* str);

struct Token_Type** RPN(struct Token_Type** list, int len, int* len_rpn);
struct Tree* Build_Tree(struct Token_Type** rpn, int len);
