#ifndef INTERFACE
#define INTERFACE

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>

typedef struct gui gui;
typedef struct object object;

typedef struct object
{
    int id;
    SDL_Rect rect;
    SDL_Color fill;     // background color
    SDL_Color border;   // border color
    SDL_Color color;    // content color (image/text)

    // image
    SDL_Surface* surface;

    //text
    TTF_Font* font;
    char* content;

    // button
    SDL_Color hover;
    int mouseOn;
    void (*click)(object*);
    void (*enter)(object*);
    void (*leave)(object*);

} object;

// Onglet
typedef struct tab
{
    int id;
    int count;
    object** objects;

    gui* ui;

} tab;

// Interface graphique
typedef struct gui
{
    int index;
    int count;
    tab** tabs;

    SDL_Color backgroundColor;
    SDL_Color fillColor;
    SDL_Color borderColor;
    SDL_Color contentColor;
    SDL_Color hoverColor;

    SDL_Window* window;
    SDL_Renderer* renderer;

} gui;

// Fonctions pour utiliser l'interface graphique
gui* init_interface(int width, int height, char* name);
void draw_interface(gui* ui);
void quit_interface(gui* ui);

// Fonctions pour configurer l'interface graphique
tab* add_tab(gui* ui);
object* add_object(tab* t, SDL_Rect rect);

void set_text(object* obj, TTF_Font* font, char* content);
void set_image(object* obj, char* path);
void set_button(object* obj, void(*click)(), void(*enter)(), void(*leave)());

#endif