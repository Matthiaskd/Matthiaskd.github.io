#include <err.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include "interface.h"

const size_t TAB_COUNT = 16;
const size_t OBJ_COUNT = 32;
const size_t BUFFER_SIZE = 256;

gui* init_interface(int width, int height, char* name)
{
	// On alloue de la mémoire pour l'interface graphique
	gui* ui = malloc(sizeof(gui));
	if (ui == NULL)
		errx(EXIT_FAILURE, "Not enough memory.\n");
	
	// Initialisation de SDL
	if (SDL_Init(SDL_INIT_VIDEO) != 0 || TTF_Init() != 0)
        errx(EXIT_FAILURE, "%s", SDL_GetError());
	
	// Configuration de l'interface graphique
	ui->index = -1;
	ui->count = 0;
	ui->tabs = malloc(TAB_COUNT * sizeof(tab));

	// Thème
	ui->backgroundColor = (SDL_Color){200, 200, 200, 255};
	ui->fillColor = (SDL_Color){190, 190, 190, 255};
	ui->borderColor = (SDL_Color){160, 160, 160, 255};
	ui->contentColor = (SDL_Color){140, 140, 140, 255};
	ui->hoverColor = (SDL_Color){180, 180, 180, 255};

	// SDL
	ui->window = SDL_CreateWindow(
		    name,
		    SDL_WINDOWPOS_UNDEFINED,
		    SDL_WINDOWPOS_UNDEFINED,
		    width,
		    height,
		    SDL_WINDOW_SHOWN | SDL_WINDOW_OPENGL);
	ui->renderer = SDL_CreateRenderer(ui->window, -1, 0);

	return ui;
}

void set_render_draw_color(SDL_Renderer* renderer, SDL_Color color) {
		SDL_SetRenderDrawColor(
			renderer, color.r, color.g, color.b, color.a);
	}

void draw_interface(gui* ui)
{
	int quit = 0;
	int clic = 0;
	int x = 0;
	int y = 0;
	
	SDL_Event event;

	while (!quit) {
		SDL_PollEvent(&event);

		if (event.type == SDL_QUIT)
			quit = 1;
		else if (event.type == SDL_MOUSEMOTION) {
			x = event.motion.x;
			y = event.motion.y;
		}
		else if (event.type == SDL_MOUSEBUTTONDOWN) {
			clic = event.button.button == SDL_BUTTON_LEFT;
		}
		else {
			clic = 0;
		}

		if (ui->index == -1)
			continue;
		
		tab* t = ui->tabs[ui->index];
		set_render_draw_color(ui->renderer, ui->backgroundColor);
		SDL_RenderClear(ui->renderer);
		
		for (int i = 0; i < t->count; i++) {
			object* obj = t->objects[i];

			if (obj->fill.a != 0) {
				set_render_draw_color(ui->renderer, obj->fill);
				SDL_RenderFillRect(ui->renderer, &obj->rect);
			}

			if (obj->mouseOn != -1) {
				int mouseOn = x >= obj->rect.x && x <= obj->rect.x + obj->rect.w 
						&& y >= obj->rect.y && y <= obj->rect.y + obj->rect.h;
				if (obj->mouseOn != mouseOn) {
					if (mouseOn) {
						if (obj->enter != NULL)
							obj->enter(obj);
					}
					else {
						if (obj->leave != NULL)
							obj->leave(obj);
					}
					obj->mouseOn = mouseOn;
				}
				if (mouseOn) {
					if (clic) {
						if (obj->click != NULL)
							obj->click(obj);
					}
					if (obj->hover.a != 0) {
						set_render_draw_color(ui->renderer, obj->hover);
						SDL_RenderFillRect(ui->renderer, &obj->rect);
					}
				}
			}
			
			if (obj->surface != NULL) {
				SDL_Texture* texture = SDL_CreateTextureFromSurface(
					ui->renderer, obj->surface);
				SDL_Rect rect;
				rect.x = obj->rect.x + 5;
				rect.y = obj->rect.y + 5;
				rect.w = obj->rect.w - 10;
				rect.h = obj->rect.h - 10;
				SDL_RenderCopy(ui->renderer, texture, NULL, &rect);
				SDL_DestroyTexture(texture);
			}

			if (obj->font != NULL) {
				SDL_Surface* surface = TTF_RenderText_Solid(
					obj->font, obj->content, obj->color);
				obj->rect.w = surface->w;
				obj->rect.h = surface->h;
				SDL_Texture* texture = SDL_CreateTextureFromSurface(
					ui->renderer, surface);
				SDL_RenderCopy(ui->renderer, texture, NULL, &obj->rect);
				SDL_DestroyTexture(texture);
				SDL_FreeSurface(surface);
			}

			if (obj->border.a != 0) {
				set_render_draw_color(ui->renderer, obj->border);
				SDL_RenderDrawRect(ui->renderer, &obj->rect);
			}
		}

		SDL_RenderPresent(ui->renderer);
	}
}

void quit_interface(gui* ui)
{
	for (int i = 0; i < ui->count; i++) {
		for (int j = 0; j < ui->tabs[i]->count; j++) {
			free(ui->tabs[i]->objects[j]);
		}
		free(ui->tabs[i]);
	}
	free(ui->tabs);

	SDL_DestroyRenderer(ui->renderer);
    SDL_DestroyWindow(ui->window);
	TTF_Quit();
    SDL_Quit();
}

tab* add_tab(gui* ui)
{
	tab* t = malloc(sizeof(tab));
	t->id = ui->count;
	t->count = 0;
	t->objects = malloc(OBJ_COUNT * sizeof(object));

	t->ui = ui;
	ui->tabs[ui->count] = t;
	ui->count++;

	return t;
}

object* add_object(tab* t, SDL_Rect rect)
{
	object* obj = malloc(sizeof(object));
	obj->id = t->count;
	obj->rect = rect;
	obj->fill = t->ui->fillColor;
	obj->border = t->ui->borderColor;
	obj->color = t->ui->contentColor;

	obj->surface = NULL;

	obj->font = NULL;
	obj->content = NULL;

	obj->hover = t->ui->hoverColor;
	obj->mouseOn = -1;
	obj->click = NULL;
	obj->enter = NULL;
	obj->leave = NULL;

	t->objects[t->count] = obj;
	t->count++;

	return obj;
}

void set_text(object* obj, TTF_Font* font, char* content)
{
	obj->font = font;
	obj->content = content;

	SDL_Surface* surface = TTF_RenderText_Solid(font, content, obj->color);
	obj->rect.w = surface->w;
	obj->rect.h = surface->h;
	SDL_FreeSurface(surface);
}

void set_image(object* obj, char* path)
{
	obj->surface = IMG_Load(path);
	
	Uint32* pixels = obj->surface->pixels;
	int len = obj->surface->w * obj->surface->h;
	SDL_PixelFormat* f = obj->surface->format;
				
	SDL_LockSurface(obj->surface);
	for (int i = 0; i < len; i++) {
		Uint8 r, g, b, a;
		SDL_GetRGBA(pixels[i], f, &r, &g, &b, &a);
		if (a != 0)
			pixels[i] = SDL_MapRGBA(
				f, obj->color.r, obj->color.g, obj->color.b, a);
	}
	SDL_UnlockSurface(obj->surface);
}

void set_button(object* obj, void(*click)(), void(*enter)(), void(*leave)())
{
	obj->mouseOn = 0;
	obj->click = click;
	obj->enter = enter;
	obj->leave = leave;
}