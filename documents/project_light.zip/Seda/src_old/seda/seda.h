#ifndef SEDA
#define SEDA

#include <err.h>
#include <stdio.h>
#include <SDL2/SDL.h>
#include <Python.h>
#include <pthread.h>
#include <Python.h>
#include "seda.h"
#include "interface.h"

void run_python_file(object* file);

#endif