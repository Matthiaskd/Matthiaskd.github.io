#include <err.h>
#include <stdio.h>
#include <SDL2/SDL.h>
#include <Python.h>
#include <pthread.h>
#include <Python.h>
#include "interface.h"

void* worker(void* arg)
{
    object* file = (object*)arg;

    setenv("PYTHONPATH",".",1);
    Py_Initialize();

    PyObject* module = PyImport_ImportModule("seda");

    if (module == NULL)
        errx(EXIT_FAILURE, "seda.py not found");

    while (1)
    {
        PyObject* refresh = PyObject_GetAttrString(module, "refresh");

        if (!refresh || !PyCallable_Check(refresh))
            errx(EXIT_FAILURE, "refresh function not found in seda.py");

        PyObject* result = PyObject_CallObject(refresh, NULL);

        if (result == NULL || !PyList_Check(result))
            errx(EXIT_FAILURE, "return value is invalid");

        //Py_ssize_t size = PyList_Size(result);

        file->rect.x = (int)PyLong_AsLong(PyList_GetItem(result, 1));
        file->rect.y = (int)PyLong_AsLong(PyList_GetItem(result, 2));
        file->rect.w = (int)PyLong_AsLong(PyList_GetItem(result, 3));
        file->rect.h = (int)PyLong_AsLong(PyList_GetItem(result, 4));
        SDL_Delay(5);
    }

    Py_Finalize();

    return (void*)NULL;
}

void run_python_file(object* file)
{
    pthread_t thr;
    pthread_create(&thr, NULL, worker, (void*)file);
}