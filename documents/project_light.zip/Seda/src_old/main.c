#include "interface.h"
#include "shunting_yard.h"
#include "memory.h"
#include "seda.h"

const int width = 400;
const int height = 600;

char* compute(char* input)
{
    int len = 0; 
    int len_rpn = 0;
    struct Token_Type** res = lexer(input, &len);
    struct Token_Type** rpn = RPN(res, len, &len_rpn);
    struct Tree* tree = Build_Tree(rpn, len_rpn);
    double res1 = computeTree(tree);

    int res0 = (int)res1;
    char* result = malloc(128);
    int i = 0;
    while (res0 != (double)0) {
        for (int j = i; j > 0; j--)
            result[j] = result[j-1];
        result[0] = '0' + (double)((int)res0 % 10);
        res0 /= 10;
        i++;
    }

    result[i] = 0;

    return result;
}

int main()
{
	gui* ui = init_interface(width, height, "SEDA Calculator");
    
    int index;
    int cursor = 1;
    char buffer[256] = {'0', 0};

    TTF_Font* titleFont = TTF_OpenFont("fonts/square.ttf", 80);
    TTF_Font* inputFont = TTF_OpenFont("fonts/pixels.ttf", 28);
    
    tab* menu = add_tab(ui);
    tab* tab1 = add_tab(ui);
    tab* tab2 = add_tab(ui);
    tab* tab3 = add_tab(ui);
    tab* tab4 = add_tab(ui);
    tab* tab5 = add_tab(ui);
    tab* tab6 = add_tab(ui);
    ui->index = menu->id;

    // Menu tab
    index = 0;
    char* menuIcons[] = {
        "assets/calculations.png", "assets/grapher.png", "assets/python.png",
        "assets/up.png", "assets/down.png", "assets/settings.png"};

    void click(object* obj) {
        ui->index = obj->id + 1;
        if (obj->id + 1 == tab3->id)
        {
            run_python_file(add_object(tab3, (SDL_Rect){0, 0, 0, 0}));
        }
    }

    void enter(object* obj) {
        obj->color = ui->backgroundColor;
        set_image(obj, menuIcons[obj->id]);
        obj->fill = ui->contentColor;
    }

    void leave(object* obj) {
        obj->color = ui->contentColor;
        set_image(obj, menuIcons[obj->id]);
        obj->fill.a = 0;
    }

    void home() {
        ui->index = menu->id;
    }

    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 3; j++) {
            SDL_Rect rect = {width/3*j + (width/3 - 60)/2, 200 + i*120, 60, 60};
            add_object(menu, rect);
            set_image(menu->objects[index], menuIcons[index]);
            set_button(menu->objects[index], click, enter, leave);
            menu->objects[index]->fill.a = 0;
            menu->objects[index]->border.a = 0;
            menu->objects[index]->hover.a = 0;
            index++;
        }
    }

    void website() {
        SDL_OpenURL("https://matthiaskd.github.io/");
    }

    menu->objects[index-1]->click = website;

    object* menuTitle = add_object(menu, (SDL_Rect){10, 10, 20, 20});
    set_text(menuTitle, titleFont, "SEDA");
    menuTitle->fill.a = 0;
    menuTitle->border.a = 0;
    menuTitle->rect.x = (width - menuTitle->rect.w)/2;
    menuTitle->rect.y = (200 - menuTitle->rect.h)/2;

    // Calculations tab
    index = 0;
    char* calculationsIcons[] = {
        "assets/home.png", "assets/up.png", "assets/down.png", "assets/trash.png",
        "assets/seven.png", "assets/eight.png", "assets/nine.png",
        "assets/four.png", "assets/five.png", "assets/six.png",
        "assets/one.png", "assets/two.png", "assets/three.png",
        "assets/sign.png", "assets/zero.png", "assets/down.png",
        "assets/left_parenthesis.png", "assets/right_parenthesis.png",
        "assets/plus.png", "assets/minus.png",
        "assets/divide.png", "assets/multiply.png",
        "assets/modulo.png", "assets/power.png", 
        "assets/sqrt.png", "assets/down.png", 
        "assets/equal.png", "assets/backspace.png", "assets/minus.png", 
        "assets/plus.png", "assets/sign.png", "assets/sign.png"};
    char symbols[] = "789456123 0.()+-/* ^  ";
    symbols[18] = '%';

    // home button
    add_object(tab1, (SDL_Rect){20, 8, 32, 32});
    set_image(tab1->objects[index], calculationsIcons[index]);
    set_button(tab1->objects[index], home, NULL, NULL);
    index++;

    for (int i = 0; i < 3; i++) {
        SDL_Rect rect = (SDL_Rect){280 + i*34, 8, 32, 32};
        add_object(tab1, rect);
        set_image(tab1->objects[index], calculationsIcons[index]);
        set_button(tab1->objects[index], NULL, NULL, NULL);
        index++;
    }

    // memory
    // memory
    object* memory[8];
    void update_memory() {
        int memoryCount = 0;
        char** lines = read_in_file(&memoryCount);

        for (int i = 0; i < memoryCount; i++) {
            int j = 0;
            while (lines[i][j] != 0)
                j++;
            lines[i][j-1] = 0;
        }

        int j = 0;
        for (int i = 0; i < (memoryCount > 8 ? 8 : memoryCount); i++) {
            set_text(memory[i], inputFont, lines[memoryCount - i - 1]);
            memory[i]->rect.x = 25 + (width - 50 - memory[i]->rect.w) * ((i+1)%2);
            memory[i]->rect.y = 50 + (7-i)*30;
            j++;
        }
        while (j < 8) {
            set_text(memory[j], inputFont, " ");
            j++;
        }
    };

    void clear_history() {
        clear_all();
        update_memory();
    };

    tab1->objects[index-1]->click = clear_history;
    
    void add_input(object* obj) {
        if (cursor == 1)
            buffer[0] = symbols[obj->id-4];
        else
            buffer[cursor-1] = symbols[obj->id-4];

        buffer[cursor] = 0;
        cursor++;
    };

    // num pad buttons
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 3; j++) {
            SDL_Rect rect = (SDL_Rect){16 + j*42, 422 + i*42, 40, 40};
            add_object(tab1, rect);
            set_image(tab1->objects[index], calculationsIcons[index]);
            set_button(tab1->objects[index], add_input, NULL, NULL);
            index++;
        }
    }

    // operators pad buttons
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 2; j++) {
            SDL_Rect rect = (SDL_Rect){156 + j*34, 422 + i*34, 32, 32};
            add_object(tab1, rect);
            set_image(tab1->objects[index], calculationsIcons[index]);
            set_button(tab1->objects[index], add_input, NULL, NULL);
            index++;
        }
    }

    void facto() {
        char* f = "facto";
        for (int i = 0; i < 5; i++) {
            buffer[cursor-1] = f[i];
            cursor++;
        }
        buffer[cursor] = 0;
        //cursor++;
    }

    tab1->objects[index-1]->click = facto;

    void equal() {
        char* expr = malloc(cursor + 1);
        for (int i = 0; i <= cursor; i++)
            expr[i] = buffer[i];
        
        char* result = compute(expr);

        write_in_file(expr);
        write_in_file(result);

        update_memory();

        cursor = 1;
        buffer[0] = '0';
        buffer[1] = 0;
    }

    void delete() {
        cursor--;
        if (cursor <= 1) {
            buffer[0] = '0';
            buffer[1] = 0;
            cursor = 1;
        }
        else {
            buffer[cursor-1] = 0;
        }
    };

    for (int i = 0; i < 2; i++) {
        add_object(tab1, (SDL_Rect){20 + i*97, 342, 95, 40});
        set_button(tab1->objects[index + i], i == 0 ? equal : delete, NULL, NULL);

        object* icon = add_object(tab1, (SDL_Rect){48 + i*97, 342, 40, 40});
        set_image(icon, calculationsIcons[index]);
        icon->fill.a = 0;
        icon->border.a = 0;
        index ++;
    }
    index += 2;

    for (int i = 0; i < 4; i++) {
        add_object(tab1, (SDL_Rect){214 + i*42, 342, 40, 40});
        set_button(tab1->objects[index], NULL, NULL, NULL);
        index++;
    }


    // layout
    add_object(tab1, (SDL_Rect){20 , 42, width - 40, 260});     // Output
    add_object(tab1, (SDL_Rect){20 , 300, width - 40, 40});     // Input
    object* input = add_object(tab1, (SDL_Rect){25, 0, 0, 0});
    set_text(input, inputFont, buffer);
    input->fill.a = 0;
    input->border.a = 0;
    input->rect.y = 300 + (40 - input->rect.h)/2;

    object* title = add_object(tab1, (SDL_Rect){10, 10, 20, 20});
    set_text(title, titleFont, "SEDA");
    title->fill.a = 0;
    title->border.a = 0;
    title->color = (SDL_Color){180, 180, 180, 255};
    title->rect.x = (width - title->rect.w)/2;
    title->rect.y = 40 + (260 - title->rect.h)/2;

    // init memory
    for (int i = 0; i < 8; i++) {
        memory[i] = add_object(tab1, (SDL_Rect){25, 50 + (7-i)*30, 0, 0});
        memory[i]->border.a = 0;
    }
    update_memory();

    /*

    buttons[index] = add_object(tab1, (SDL_Rect){298, 342, 82, 40});
    set_button(buttons[index], delete, NULL, NULL);

    object* deleteButton = add_object(tab1, (SDL_Rect){313, 337, 50, 50});
    deleteButton->color = (SDL_Color){120, 50, 50, 255};
    set_image(deleteButton, icons[index]);
    deleteButton->fill.a = 0;
    deleteButton->border.a = 0;
    index++;*/

    // Grapher tab
    index = 0;
    char* grapherIcons[] = {
        "assets/home.png"};
    
    add_object(tab2, (SDL_Rect){20, 8, 32, 32});
    set_image(tab2->objects[index], grapherIcons[index]);
    set_button(tab2->objects[index], home, NULL, NULL);
    index++;

    add_object(tab2, (SDL_Rect){20 , 60, width - 40, 240});

    // Python tab
    tab* pythonWindow = add_tab(ui);

    /*
    index = 0;
    char* pythonIcons[] = {
        "assets/home.png"};
    
    add_object(tab3, (SDL_Rect){20, 8, 32, 32});
    set_image(tab3->objects[index], pythonIcons[index]);
    set_button(tab3->objects[index], home, NULL, NULL);
    index++;

    add_object(tab3, (SDL_Rect){20 , 300, width - 40, 40});
    */

    // tab4
    index = 0;
    char* tab4Icons[] = {
        "assets/home.png"};
    
    add_object(tab4, (SDL_Rect){20, 8, 32, 32});
    set_image(tab4->objects[index], tab4Icons[index]);
    set_button(tab4->objects[index], home, NULL, NULL);
    index++;

    add_object(tab2, (SDL_Rect){20 , 60, width - 40, 240});

    // tab5
    index = 0;
    char* tab5Icons[] = {
        "assets/home.png"};
    
    add_object(tab5, (SDL_Rect){20, 8, 32, 32});
    set_image(tab5->objects[index], tab5Icons[index]);
    set_button(tab5->objects[index], home, NULL, NULL);
    index++;

    add_object(tab2, (SDL_Rect){20 , 60, width - 40, 240});

    // tab6
    index = 0;
    char* tab6Icons[] = {
        "assets/home.png"};
    
    add_object(tab6, (SDL_Rect){20, 8, 32, 32});
    set_image(tab6->objects[index], tab6Icons[index]);
    set_button(tab6->objects[index], home, NULL, NULL);
    index++;

    add_object(tab2, (SDL_Rect){20 , 60, width - 40, 240});


    draw_interface(ui);
    quit_interface(ui);
    
    return 0;
}