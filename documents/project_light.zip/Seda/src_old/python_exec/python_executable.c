#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    // Vérifiez s'il existe un argument de ligne de commande
    if (argc < 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    // Ouvrez le fichier en lecture
    FILE *fp;
    fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Error opening file %s\n", argv[1]);
        return 1;
    }

    // Calculez la taille du fichier
    fseek(fp, 0, SEEK_END);
    size_t size = ftell(fp);
    rewind(fp);

    // Allouez de la mémoire pour le contenu du fichier
    char *content = malloc(size + 1);
    if (content == NULL) {
        printf("Error allocating memory\n");
        fclose(fp);
        return 1;
    }

    // Lit le contenu du fichier dans une chaîne de caractères
    size_t read = fread(content, 1, size, fp);
    if (read != size) {
        printf("Error reading file\n");
        free(content);
        fclose(fp);
        return 1;
    }

    // Ajoutez un caractère de fin de ligne pour la commande système
    content[size] = '\0';

    // Fermez le fichier
    fclose(fp);

    // Exécutez le code Python en utilisant la commande système
    char command[10000];
    snprintf(command, sizeof(command), "python -c \"%s\"", content);
    int result = system(command);

    // Libérez la mémoire allouée pour le contenu du fichier
    free(content);

    // Renvoie le résultat de l
    return result;
}
