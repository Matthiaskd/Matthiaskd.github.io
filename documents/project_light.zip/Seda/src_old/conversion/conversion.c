#include <stdio.h>
#include <string.h>

// Unit conversion tables
double conversionTable[5][13] = {
    {1.0, 0.1, 0.01, 0.001, 0.000001, 0.00000001, 0.000000001, 0.0393701, 0.00328084, 0.00109361, 0.000000621371, 0.000000539957, 0.000000493737},
    {1000.0, 1.0, 0.001, 0.000001, 0.000001, 0.00000001, 0.000000001, 39.3701, 3.28084, 1.09361, 0.000621371, 0.000539957, 0.000493737},
    {10000.0, 10.0, 1.0, 0.01, 0.00001, 0.0000001, 0.00000001, 393.701, 32.8084, 10.9361, 0.00621371, 0.00539957, 0.00493737},
    {1000000.0, 1000.0, 100.0, 1.0, 0.001, 0.00001, 0.000001, 39370.1, 3280.84, 1093.61, 0.621371, 0.539957, 0.493737},
    {1000000000.0, 1000000.0, 100000.0, 1000.0, 1.0, 0.01, 0.001, 39370079.0, 3280840.0, 1093610.0, 621.371, 539.957, 493.737},
};

// Currency conversion rates
double currencyConversionTable[10][10] = {
    {1.0, 1.2183, 0.8593, 1.5133, 1.6285, 131.6702, 1.0848, 7.7851, 1.7205, 9.5257},
    {0.8207, 1.0, 0.7075, 1.2425, 1.3347, 107.8152, 0.8923, 6.4078, 1.4171, 7.8397},
    {1.1633, 1.4132, 1.0, 1.7582, 1.8899, 152.3994, 1.2612, 9.0501, 2.0021, 11.0833},
    {0.6617, 0.8024, 0.5676, 1.0, 1.0741, 86.6177, 0.7175, 5.1497, 1.1386, 6.3035},
    {0.6149, 0.7434, 0.5254, 0.9306, 1.0, 80.5759, 0.6675, 4.7873, 1.0592, 5.8561},
    {0.0076, 0.0092, 0.0065, 0.0115, 0.0124, 1.0, 0.0083, 0.0595, 0.0132, 0.0731},
    {0.9211, 1.1162, 0.7882, 1.3869, 1.4915, 120.2547, 1.0, 7.1765, 1.5863, 8.7842},
    {0.1286, 0.156, 0.1102, 0.1943, 0.2089, 16.8452, 0.1392, 1.0, 0.2213, 1.2251},
    {0.5817, 0.7056, 0.4986, 0.8767, 0.9435, 76.1535, 0.6313, 4.5278, 1.0, 5.5264},
    {0.1051, 0.1273, 0.0900, 0.1583, 0.1702, 13.7535, 0.1141, 0.8199, 0.1810, 1.0}
};

// Unit names
const char units[5][15][20] = {
    {"mm", "cm", "dm", "m", "km", "dam", "hm", "inch", "foot", "yard", "mile", "nmile", "league"},
    {"mg", "g", "kg", "ton", "ounce", "pound", "stone"},
    {"ml", "cl", "dl", "liter", "m3", "barrel", "gallon", "quart", "pint", "cup", "ounce", "tablespoon", "teaspoon"},
    {"seconds", "minutes", "hours", "days", "weeks", "months", "years"},
    {"Euro", "USD", "GBP", "CAD", "AUD", "JPY", "CHF", "CNY", "NZD", "HKD"}
};

// Function to display available units
void displayUnits(int type) {
    switch (type) {
        case 0: // Length
            printf("Available length units (type 0):\n");
            for (int i = 0; i < 13; i++) {
                printf("%d. %s\n", i, units[type][i]);
            }
            break;
        case 1: // Mass
            printf("Available mass units (type 1):\n");
            for (int i = 0; i < 7; i++) {
                printf("%d. %s\n", i, units[type][i]);
            }
            break;
        case 2: // Volume
            printf("Available volume units (type 2):\n");
            for (int i = 0; i < 13; i++) {
                printf("%d. %s\n", i, units[type][i]);
            }
            break;
        case 3: // Time
            printf("Available time units (type 3):\n");
            for (int i = 0; i < 7; i++) {
                printf("%d. %s\n", i, units[type][i]);
            }
            break;
        case 4: // Currency
            printf("Available currency units (type 4):\n");
            for (int i = 0; i < 10; i++) {
                printf("%d. %s\n", i, units[type][i]);
            }
            break;
        case 5: // Surface
            printf("Available surface units (type 5):\n");
            for (int i = 0; i < 6; i++) {
                printf("%d. %s\n", i, units[type][i]);
            }
            break;
        default:
            printf("Invalid unit type\n");
            break;
    }
}

// Function to convert units
void convert(int type, double value, int unitFromIndex, int unitToIndex) {
    double result = value / conversionTable[type][unitFromIndex] * conversionTable[type][unitToIndex];
    printf("%.4f %s = %.4f %s\n", value, units[type][unitFromIndex], result, units[type][unitToIndex]);
}

int main() {
    char input[20];
    int unitType;

    while (1) {
        printf("Enter unit type or 'help' for available unit types: ");
        scanf("%s", input);

        if (strcmp(input, "length") == 0) {
            unitType = 0;
        } else if (strcmp(input, "mass") == 0) {
            unitType = 1;
        } else if (strcmp(input, "volume") == 0) {
            unitType = 2;
        } else if (strcmp(input, "time") == 0) {
            unitType = 3;
        } else if (strcmp(input, "currency") == 0) {
            unitType = 4;
        } else if (strcmp(input, "surface") == 0) {
            unitType = 5;
        } else if (strcmp(input, "help") == 0) {
            printf("Available unit types:\n");
            printf("0. Length\n");
            printf("1. Mass\n");
            printf("2. Volume\n");
            printf("3. Time\n");
            printf("4. Currency\n");
            printf("5. Surface\n");
        } else {
            printf("Invalid unit type\n");
            break;
        }

        printf("Enter unit to convert from or type 'units': ");
        char unitFrom[20];
        scanf("%s", unitFrom);

	if (strcmp(unitFrom, "units") == 0) {
            displayUnits(unitType);
        } else {
        
	printf("Enter unit to convert to: ");
        char unitTo[20];
        scanf("%s", unitTo);

        printf("Enter value: ");
        double value;
        scanf("%lf", &value);
        
            int unitFromIndex = -1;
            int unitToIndex = -1;

            // Find unit index in the conversion table
            for (int i = 0; i < 15; i++) {
                if (strcmp(unitFrom, units[unitType][i]) == 0) {
                    unitFromIndex = i;
                }

                if (strcmp(unitTo, units[unitType][i]) == 0) {
                    unitToIndex = i;
                }
            }

            if (unitFromIndex != -1 && unitToIndex != -1) {
                convert(unitType, value, unitFromIndex, unitToIndex);
            } else {
                printf("Invalid units\n");
            }
        }
    }

    return 0;
}

