import importlib

module = importlib.import_module("test")

def draw_rect(type, x, y, w, h):
    if type == "fill":
        data.append(1)
    elif type == "line":
        data.append(0)
    else:
        raise Exception(type + " is not line nor fill")
    data.append(x)
    data.append(y)
    data.append(w)
    data.append(h)

module.draw_rect = draw_rect
module.get_width = lambda: 400
module.get_height = lambda: 600

if hasattr(module, 'load'):
    module.load()

data = []

def refresh():
    for i in range(len(data)):
        data.pop()

    if hasattr(module, 'update'):
        module.update()
    if hasattr(module, 'draw'):
        module.draw()
    return data