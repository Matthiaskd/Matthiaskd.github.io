w = None
h = None

x = 0
y = 0
size = 60

dx = 2
dy = 2

def load():
    global w
    global h
    w = get_width()
    h = get_height()

def update():
    global x
    global y
    global dx
    global dy
    x = x + dx
    y = y + dy
    if x == 0 or x == w - size:
        dx = -dx
    if y == 0 or y == h - size:
        dy = -dy

def draw():
    draw_rect("fill", x, y, size, size)