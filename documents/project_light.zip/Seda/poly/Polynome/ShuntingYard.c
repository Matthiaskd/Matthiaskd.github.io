#include<stdio.h>
#include<stdlib.h>
#include"queue_stack.h"
#include"lexer.h"
#include "poly.h"
#include<err.h>
#include<math.h>

struct queue* ShuntingYard(struct queue* input){
    struct stack* operators = Stack();
    struct queue* output = Queue();
    while(! q_isempty(input)){
        struct token* curr = dequeue(input);
        if(curr->prec == DIGIT || curr->prec == POLYNOME){
            enqueue(output, curr);
        }
        else if(curr->prec != DIGIT && curr->prec != PARENTHESIS){
            while(! s_isempty(operators) && 
                operators->next->value->value!='(' &&
                (operators->next->value->prec > curr->prec||((operators->next->value->prec == curr->prec) && curr->asso == L))){
                    enqueue(output, pop(operators));
            }
            push(operators, curr);
        }   
        else if (curr->prec == PARENTHESIS){
            if(curr->value == '('){
                push(operators, curr);
            }
            else{
                struct token* t2=NULL;
                while(! s_isempty(operators) && (t2 = pop(operators))->value!='('){
                        enqueue(output, t2);
                }
                free(curr);
                free(t2);
            }
        }
    }
    while(!s_isempty(operators)){
        struct token* T3 = pop(operators);
        if(T3->prec != PARENTHESIS)
            enqueue(output, T3);
        else    
            free(T3);
    }
    free_queue(input);
    free_stack(operators);
    return output;
}


struct poly* eval(struct queue* exp){
    struct stack* s = Stack();
    
    struct poly* P = init();
    while(! q_isempty(exp)){
        
        struct token* t;

        while(!q_isempty(exp)&&((t=dequeue(exp))->prec == DIGIT || t->prec == POLYNOME)){
            push(s, t);
        }
        
        struct token* op2 = pop(s);
        struct token* op1 = pop(s);
        
        if(t->value ==(double) '^'){
            if(op2->prec == POLYNOME){
                errx(1, "n^x");
            } else if(op1->prec == POLYNOME){
                op1->asso *= op2->value;
            } else{
                int a = op1->value;
                int b = op2->value;
                int res = 1;
                while(b>0){
                    res*=a;
                    b-=1;
                }
                op1->value = res;
            }
            free(op2);
            push(s, op1);
        }else if(t->value == (double)'*'){
            if(op1->prec == POLYNOME){// a.x^n * b.x^m
                if(op2->prec == POLYNOME){
                    op1->value*=op2->value;
                    op1->asso+=op2->asso;
                } else{
                    op1->asso *= op2->value;
                }
                push(s, op1);
                free(op2);
            } else if (op2->prec == POLYNOME){
                op2->value *= op1->value;
                push(s, op2);
                free(op1);
            } else{
                op1->value *= op2->value;
                free(op2);
                push(s, op1);
            }
        }else if(t->value == (double)'/'){
            if(op2->prec == DIGIT && op2->value == 0)
                errx(1, "/0\n");
            if(op1->prec == POLYNOME){// a.x^n / b.x^m
                if(op2->prec == POLYNOME){
                    op1->value/=op2->value;
                    op1->asso-=op2->asso;
                } else{
                    op1->value /= op2->value;
                }
                push(s, op1);
                free(op2);
            } else if (op2->prec == POLYNOME){
                op2->asso /= op1->value;
                push(s, op2);
                free(op1);
            } else{
                op1->value /= op2->value;
                free(op2);
                push(s, op1);
            }
        }else if(t->value ==(double) '+'){
            
            if(op1->prec == POLYNOME){
                struct poly* p1 = init();
                p1->degree = op1->asso;
                p1->value = op1->value;
                append_p(P, p1);
                free(op1);
                if(op2->prec == POLYNOME){
                    struct poly* p2 = init();
                    p2->degree = op2->asso;
                    p2->value = op2->value;
                    append_p(P, p2);
                    op2->value = 0;
                    op2->prec = DIGIT;
                    op2->asso = L;
                }
                push(s, op2);
            } else if(op2->prec == POLYNOME){
                    struct poly* p2 = init();
                    p2->degree = op2->asso;
                    p2->value = op2->value;
                    append_p(P, p2);
                    free(op2);
                    push(s, op1);
            } else{
                op1->value += op2->value;
                free(op2);
                push(s, op1);
            }
        }else if(t->value == (double)'-'){
            if(op1->prec == POLYNOME){
                struct poly* p1 = init();
                p1->degree = op1->asso;
                p1->value = op1->value;
                append_p(P, p1);
                free(op1);
                
                if(op2->prec == POLYNOME){
                    struct poly* p2 = init();
                    p2->degree = op2->asso;
                    p2->value = -op2->value;
                    append_p(P, p2);
                    free(op2);
                    struct token* zero = new_token();
                    zero->value = 0;
                    zero->prec = DIGIT;
                    zero->asso = L;
                    push(s, zero);
                }
                else {
                    op2->value*=-1;
                    push(s, op2);
                }
                
            } else if(op2->prec == POLYNOME){
                    struct poly* p2 = init();
                    p2->degree = op2->asso;
                    p2->value = -op2->value;
                    append_p(P, p2);
                    
                    free(op2);
                    push(s, op1);
            } else{
                op1->value -= op2->value;
                free(op2);
                push(s, op1);
            }
        }  else if(t->prec==POLYNOME){
            push(s, t);
            break;
        }
        free(t);    
    }
    
    struct token* last_token = pop(s);
    if(last_token==NULL){
        free(last_token);
        errx(1, "not enough opearands\n"); 
    }
    else{
        if(last_token->prec == DIGIT && last_token->value!=0){
            struct poly* last_poly = init();
            last_poly->degree =0;
            last_poly->value = last_token->value;
            append_p(P, last_poly);
        } else if(last_token->prec == POLYNOME){
            struct poly* last_poly = init();
            last_poly->degree = last_token->asso;
            last_poly->value = last_token->value;
                append_p(P, last_poly);
        }
        free(last_token);
    }
    if(!s_isempty(s))
        errx(1, "too many operands\n");
    free_queue(exp);
    free_stack(s);
    return P;
}