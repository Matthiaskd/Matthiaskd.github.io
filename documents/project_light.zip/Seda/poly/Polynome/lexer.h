#pragma once
#define POWER 4
#define MULTIDIV 3
#define PLUSMINUS 2
#define POLYNOME 5
#define DIGIT 1
#define PARENTHESIS 0
#define L 1
#define R 2


int is_digit(char c);
struct token* new_token(void);
struct queue* lex(char* input);
