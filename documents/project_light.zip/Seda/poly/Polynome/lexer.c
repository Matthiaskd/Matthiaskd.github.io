#include<stdio.h>
#include<stdlib.h>
#include "queue_stack.h"

//precedence
#define POWER 4
#define MULTIDIV 3
#define PLUSMINUS 2
#define POLYNOME 5
#define DIGIT 1
#define PARENTHESIS 0
//associativity
#define L 1
#define R 2

int is_digit(char c){
    return c>='0' && c<='9'; 
}
struct token* new_token(void){
    struct token* t = malloc(sizeof(struct token));
    return t;
}
struct queue* lex(char* input){
    struct queue* q = Queue();
    size_t len = 0;
    int last = 0;
    while(*(input+len)!=0){
        char curr = *(input+len);
        if(curr == ' '){
            len+=1;
            continue;
        } else{
            struct token* t= new_token();
            t->value = curr; 
            t->asso = L;
            if(curr == '+' || curr == '-'){
                if(*(input+len+1)=='(' && curr =='-')
                    last = 1;
                if(len==0 || (len>0&&(*(input+len-1)=='('))){//recently added(unary)
                    struct token* tok = new_token();
                    tok->prec=DIGIT;
                    tok->value=0;
                    tok->asso=L;
                    enqueue(q, tok);
                    // if(curr == '-')
                    //     last =1;
                }
                t->prec = PLUSMINUS;
            } else if(curr == '*' || curr == '/'){
                t->prec = MULTIDIV;
            } else if(curr == 'x'){
                t->prec = POLYNOME;
                if(last)
                    t->value =-1;
                else
                    t->value = 1;
            } else if(curr == '(' || curr == ')'){
                t->prec = PARENTHESIS;
                if(curr == ')')
                    last = 0;
            } else if(curr =='^'){
                t->prec = POWER;
                t->asso = R;
            } else{
                double i = 0;
                while(is_digit(curr) && curr!=0){
                    i*=10;
                    i+=curr-'0';
                    len+=1;
                    curr = *(input + len);
                }
                t->value = i;
                // printf("t->value:%f\n", t->value);
                t->prec =DIGIT;
                enqueue(q, t);
                continue;
            }
            enqueue(q, t);
        }
        len+=1;
    }
    return q;
}