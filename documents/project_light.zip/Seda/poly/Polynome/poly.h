#include<stdio.h>
#include<stdlib.h>

struct poly{
    struct poly* next;
    struct poly* last;
    double value;
    double degree;
};

struct solution{
    struct solution* next;
    double value;
};


struct poly* init(void);
void fill2(char* values, struct poly* p);
void free_poly(struct poly* p);
struct poly* factorise(struct poly* old, double f);
struct solution* init_solution(void);
void append_s(struct solution* S, struct solution* n);
void free_solution(struct solution* s);
void print_solution(struct solution* s);
void append_p(struct poly* p, struct poly* q);
void sort(struct poly* p);
void flattern(struct poly* p);