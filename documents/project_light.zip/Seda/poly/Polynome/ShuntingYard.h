#pragma once
struct queue* ShuntingYard(struct queue* q);
struct poly* eval(struct queue* exp);