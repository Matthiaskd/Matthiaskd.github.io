#include<stdio.h>
#include<stdlib.h>



// a linked list that contains the coefficients of
//the polynomial in descending order of degree
struct poly{
    struct poly* next;
    struct poly* last;
    double value;//change value to coeff
    double degree;
};

void append_p(struct poly* p, struct poly* q){ // dont forget the .h
    if(p->next == NULL){
        p->next = q;
        p->last = q;
    }
    else{
        p->last->next = q;
        p->last = q;
    }
    
}

//linked list that contains the solutions of a polynomial
//no sentinel
struct solution{
    struct solution* next;
    double value;
};

struct solution* init_solution(void){
    struct solution* s = malloc(sizeof(struct solution));
    s->next = NULL;
    return s;
}
void print_solution(struct solution* s){
    struct solution* cpy = s;
    while(cpy){
        printf("%f ", cpy->value);
        cpy = cpy->next;
    }
    printf("\n");

}
void free_solution(struct solution* s){
    while(s->next){
        struct solution* s2 = s->next;
        free(s);
        s = s2;
    }
    free(s);
}
void append_s(struct solution* S, struct solution* n){
    struct solution* new = S;
    while(new->next){
        new = new->next;
    }
    new->next = n;
}

struct poly* init(void){
        struct poly* p = malloc(sizeof(struct poly));
        p->last = NULL;
        p->next = NULL;
        return p;
}

void flattern(struct poly* p){
    struct poly* aux = p->next; 
    while(aux){
        struct poly* tmp = aux;
        while(tmp->next){
            if(tmp->next->degree == aux->degree){
                aux->value+=tmp->next->value;
                tmp->next->value = 0;
            }
            tmp = tmp->next;
        }
        aux = aux->next;
    }
    aux=p;
    while(aux && aux->next){
        struct poly* aux2 = aux;
        while(aux2 && aux2->next && aux2->next->value==0){
            struct poly* to_free = aux2->next;
            aux2->next = to_free->next;
            if(aux2->last == to_free)
                aux2->last = aux;
            free(to_free);
            aux2 = aux2->next;
        }
        aux = aux->next;
    }
    if(p && p->next && p->next->value == 0){
        struct poly* pl = p->next;
        p->next = p->next->next;
        free(pl);
    }
}

void free_poly(struct poly* p){
    while(p->next){
        struct poly* next = p->next;
        free(p);
        p = next;
    }
    free(p->last);
    free(p);
}

void sort(struct poly* p){
    struct poly* q = p->next;
    while(q){
        struct poly* cp = q->next;
        while(cp){
            if(cp->degree>q->degree){
                double tmp = cp->degree;
                cp->degree = q->degree;
                q->degree =tmp;

                tmp = cp->value;
                cp->value = q->value;
                q->value = tmp;
            }
            cp=cp->next;
        }
        q= q->next;
    }   
}


struct poly* factorise(struct poly* old, double f){

    struct poly* res = init();
    double last=0;
    struct poly* p = old;
    if(old)
        p=p->next;
    
    while(p){
        double coeff = last*f + p->value ;
        struct poly* next = init();
        next->value = coeff;
        next->degree = p->degree - 1;
        if(next->degree<0)
            next->degree = 0;//opt
        append_p(res, next);
        last = coeff;
        p = p->next;
    }
    
    flattern(res);
    return res;
}