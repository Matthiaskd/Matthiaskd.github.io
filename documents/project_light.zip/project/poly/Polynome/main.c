#include<stdio.h>
#include<stdlib.h>
#include "queue_stack.h"
#include "lexer.h"
#include "ShuntingYard.h"
#include "poly.h"
#include<err.h>
#include"root.h"

struct solution* test(char** argv){
    struct queue* q = ShuntingYard(lex(argv[1]));
    struct poly* P  = eval(q);
    
    flattern(P);
    sort(P);
    struct solution* S = solve(P);
    if(P!=NULL)
        free_poly(P);
    
    return S;
}


int main(int argc, char** argv){   
    if(argc!=2)
        return 1;
    struct solution* S = test(argv);
    print_solution(S);
    if(S!=NULL)
        free_solution(S);

    return 0;
}