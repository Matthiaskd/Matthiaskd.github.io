#pragma once
struct token{
    double value;
    int prec;
    int asso;
};

struct stack{
    struct stack* next;
    struct token* value;
};

struct stack* Stack(void);
void push(struct stack* s, struct token* x);
struct token* pop(struct stack* s);
void  free_stack(struct stack* s);

struct queue{
    struct queue* next;
    struct queue* previous;
    struct queue* last;  
    struct token* value; 
};

struct queue* Queue(void);
void enqueue(struct queue* q, struct token* x);
struct token* dequeue(struct queue* q);
void free_queue(struct queue* q);
void print_s(struct stack* s);
void print_q(struct queue* q);
int s_isempty(struct stack* s);
int q_isempty(struct queue* q);

