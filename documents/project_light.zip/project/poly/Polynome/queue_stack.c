#include<stdio.h>
#include<stdlib.h>
struct token{
    double value;//degree for poly
    int prec; 
    int asso;//coeff for poly (starts at 1)
};

struct stack{
    struct stack* next;
    struct token* value;
};

struct stack* Stack(void){
    struct stack* s = malloc(sizeof(struct stack));
    s->next = NULL;
    return s;
}  

void push(struct stack* s, struct token* x){
    struct stack* new = Stack();
    new->value = x;
    new->next = s->next;
    s->next = new;
}

struct token* pop(struct stack* s){
    if(s->next != NULL){
        struct stack* tmp = s->next;
        s->next = tmp->next;
        struct token* t = tmp->value;
        if(s->next == s)
            s->next = NULL;
        free(tmp);
        return t;
    }
    return NULL;
}

int s_isempty(struct stack* s){
    return s->next == NULL;
}

void  free_stack(struct stack* s){
    while(s->next){
        free(pop(s));
    }
    free(s);
}

//___________________________________queue structure___________________________

struct queue{
    struct queue* next;
    struct queue* previous;
    struct queue* last;  
    struct token* value; 
};

struct queue* Queue(void){
    struct queue* q = malloc(sizeof(struct queue));
    q->next = NULL;
    q->last = NULL;
    q->previous = NULL;
    return q;
}

void enqueue(struct queue* q, struct token* x){

    struct queue* new = Queue();
    new->value = x;

    if(q->next == NULL){
        q->next = new;
        q->last = new;
        new->previous = q;
    }
    else{
        new->previous = q;
        new->last = q->last;
        new->next = q->next;
        new->next->previous = new;
        q->next = new;
    }
}

struct token* dequeue(struct queue* q){
    if(q->last!=NULL){
        struct queue* tmp = q->last;
        q->last = q->last->previous;
        q->last->next = NULL;
        struct token* t = tmp->value;
        free(tmp);

        if(q->next == q){
            q->next = NULL;
            q->last = NULL;
        }

        return t; 
    }  
    return NULL; 
}
void free_queue(struct queue* q){
    while(q->next){
        free(dequeue(q));
    }
    free(q);
}

int q_isempty(struct queue* q){
    return q->next == NULL;
}



