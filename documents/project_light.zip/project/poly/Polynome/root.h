#pragma once
double evaluate(struct poly* p, double x);
struct solution* remarkable(struct poly* p);
struct solution* non_remarkable(struct poly *p);
struct sol* bisection(struct poly* p, double a, double b);
struct poly* f_prime(struct poly* p);
double aux_find_root(struct poly* p, double inf);
double find_root(struct poly* p);
struct solution* solve(struct poly*);
struct solution* linear(struct poly* p);
