#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "shunting_yard.h"

enum Operation_Type
{
    plus,
    minus,
    mult,
    division,
    mod,
    power
};
enum Associativity
{
    left,
    right
};

struct Stack2* createStack2(int capacity)
{
    struct Stack2* stack = malloc(sizeof(struct Stack));
    stack->capacity = capacity;
    stack->top = -1;
    stack->array = malloc(stack->capacity * sizeof(struct Tree));
    return stack;
}

int isFull2(struct Stack2* stack)
{
    return (stack->top == stack->capacity - 1);
}

int stack_isEmpty2(struct Stack2* stack)
{
    return (stack->top == -1);
}

void push2(struct Stack2* stack, struct Tree* tree)
{
    if (isFull2(stack))
    {
        errx(1,"pop Stack Empty");
        return;
    }   

    stack->array[++stack->top] = tree;
}

struct Tree* pop2(struct Stack2* stack)
{
    if (stack_isEmpty2(stack))
    {
        errx(1,"pop Stack Empty");
        return NULL;
    }

    return stack->array[stack->top--];
}

struct Tree* seek2(struct Stack2* stack)
{
    return (stack->array[stack->top]);
}

struct Tree* create_tree(struct Token_Type* data)
{
    struct Tree* new = malloc(sizeof(struct Tree));
    new->data = data;
    new->left = NULL;
    new->right = NULL;
    return new;
}

struct Queue* createQueue()
{
    struct Queue* queue = malloc(sizeof(struct Queue));
    queue->front = NULL; 
    queue->rear = NULL;
    return queue;
}

int queue_isEmpty(struct Queue* queue)
{
    return (queue->front == NULL);
}

void enqueue(struct Queue* queue, struct Token_Type* token)
{
    struct Node* temp = malloc(sizeof(struct Node));
    temp->data = token;
    temp->next = NULL;

    if (queue->rear == NULL) {
        queue->front = queue->rear = temp;
        return;
    }

    queue->rear->next = temp;
    queue->rear = temp;
}

struct Token_Type* dequeue(struct Queue* queue)
{
    if (queue_isEmpty(queue)) {
        printf("Queue is empty.\n");
        return NULL;
    }

    struct Node* temp = queue->front;
    struct Token_Type* item = temp->data;
    queue->front = queue->front->next;

    if (queue->front == NULL)
        queue->rear = NULL;

    free(temp);
    return item;
}

struct Stack* createStack(int capacity)
{
    struct Stack* stack = malloc(sizeof(struct Stack));
    stack->capacity = capacity;
    stack->top = -1;
    stack->array = malloc(stack->capacity * sizeof(struct Token_Type));
    return stack;
}

int isFull(struct Stack* stack)
{
    return (stack->top == stack->capacity - 1);
}

int stack_isEmpty(struct Stack* stack)
{
    return (stack->top == -1);
}

void push(struct Stack* stack, struct Token_Type* token)
{
    if (isFull(stack))
    {
        errx(1,"pop Stack Empty");
        return;
    }   

    stack->array[++stack->top] = token;
}

struct Token_Type* pop(struct Stack* stack)
{
    if (stack_isEmpty(stack))
    {
        errx(1,"pop Stack Empty");
        return NULL;
    }

    return stack->array[stack->top--];
}

struct Token_Type* seek(struct Stack* stack)
{
    return (stack->array[stack->top]);
}

struct Token_Type* Create_Plus_Token()
{
    struct Token_Type* new = malloc(sizeof(struct Token_Type));
    new->operands = NULL;
    new->paranthese = NULL;
    new->operator = malloc(sizeof(struct Token_Operators));
    new->operator->precedence = 0;
    new->operator->associativity = left;
    new->operator->operation_type = plus; 
    new->operator->nb_operands = 2; 

    return new;
}

struct Token_Type* Create_Minus_Token()
{
    struct Token_Type* new = malloc(sizeof(struct Token_Type));
    new->operands = NULL;
    new->paranthese = NULL;
    new->operator = malloc(sizeof(struct Token_Operators));
    new->operator->precedence = 0;
    new->operator->associativity = left;
    new->operator->operation_type = minus; 
    new->operator->nb_operands = 2; 

    return new;
}

struct Token_Type* Create_Mult_Token()
{
    struct Token_Type* new = malloc(sizeof(struct Token_Type));
    new->operands = NULL;
    new->paranthese = NULL;
    new->operator = malloc(sizeof(struct Token_Operators));
    new->operator->precedence = 5;
    new->operator->associativity = left;
    new->operator->operation_type = mult; 
    new->operator->nb_operands = 2;

    return new;
}

struct Token_Type* Create_Div_Token()
{
    struct Token_Type* new = malloc(sizeof(struct Token_Type));
    new->operands = NULL;
    new->paranthese = NULL;
    new->operator = malloc(sizeof(struct Token_Operators));
    new->operator->precedence = 5;
    new->operator->associativity = left;
    new->operator->operation_type = division; 
    new->operator->nb_operands = 2;

    return new;
}

struct Token_Type* Create_Mod_Token()
{
    struct Token_Type* new = malloc(sizeof(struct Token_Type));
    new->operands = NULL;
    new->paranthese = NULL;
    new->operator = malloc(sizeof(struct Token_Operators));
    new->operator->precedence = 5;
    new->operator->associativity = left;
    new->operator->operation_type = mod; 
    new->operator->nb_operands = 2;

    return new;
}

struct Token_Type* Create_Pow_Token()
{
    struct Token_Type* new = malloc(sizeof(struct Token_Type));
    new->operands = NULL;
    new->paranthese = NULL;
    new->operator = malloc(sizeof(struct Token_Operators));
    new->operator->precedence = 10;
    new->operator->associativity = right;
    new->operator->operation_type = power; 
    new->operator->nb_operands = 2;

    return new;
}

struct Token_Type* Create_Number_Token(int value)
{
    struct Token_Type* new = malloc(sizeof(struct Token_Type));
    new->operands = malloc(sizeof(struct Token_Operators));
    new->paranthese = NULL;
    new->operator = NULL;
    if (value > 0)
        new->operands->is_unary = 0;
    else
        new->operands->is_unary = 1;
    new->operands->value = value;

    return new;
}

struct Token_Type* Create_Parenthese_Token(int left)
{
    struct Token_Type* new = malloc(sizeof(struct Token_Type));
    new->operands = NULL;
    new->paranthese = malloc(sizeof(struct Token_Parenthese));
    new->operator = NULL;
    if (left == 1)
    {
        new->paranthese->is_left = 1;
        new->paranthese->is_right = 0;
    }
    else
    {
        new->paranthese->is_left = 0;
        new->paranthese->is_right = 1;
    }
    return new;
}

struct Token_Type** lexer(char* s, int* len)
{
    struct Token_Type** res = malloc(sizeof(struct Token_Type));
    int count = 0;
    size_t i = 0;

    while (s[i] != 0)
    {
        if (s[i] == ' ')
        {
            i++;
            continue;
        }
        if (s[i] == '+')
        {
            struct Token_Type* new = Create_Plus_Token();
            count++;
            res = realloc(res,count*sizeof(struct Token_Type));
            res[count-1] = new;  
        }

        else if (s[i] == '-')
        {
            struct Token_Type* new = Create_Minus_Token();
            count++;
            res = realloc(res,count*sizeof(struct Token_Type));
            res[count-1] = new;
        }

        else if (s[i] == '*')
        {
            struct Token_Type* new = Create_Mult_Token();
            count++;
            res = realloc(res,count*sizeof(struct Token_Type));
            res[count-1] = new;
        }

        else if (s[i] == '/')
        {
            struct Token_Type* new = Create_Div_Token();
            count++;
            res = realloc(res,count*sizeof(struct Token_Type));
            res[count-1] = new;
        }

        else if (s[i] == '%')
        {
            struct Token_Type* new = Create_Mod_Token();
            count++;
            res = realloc(res,count*sizeof(struct Token_Type));
            res[count-1] = new;
        }

        else if (s[i] == '^')
        {
            struct Token_Type* new = Create_Pow_Token();
            count++;
            res = realloc(res,count*sizeof(struct Token_Type));
            res[count-1] = new;
        }

        else if (s[i] >= '0' && s[i] <= '9')
        {
            char* nb = malloc(sizeof(char));
            nb[0] = s[i];
            char c0 = s[i+1];
            int count0 = 1;
            while(c0 >= '0' && c0 <= '9')
            {
                count0++;
                nb = realloc(nb,count0);
                nb[count0-1] = c0;
                nb[count0] = 0;
                c0 = s[i+count0];
            }
            i += count0 - 1;
            count++;
            res = realloc(res,count*sizeof(struct Token_Type));
            int value = atoi(nb);
            struct Token_Type* new = Create_Number_Token(value);
            res[count-1] = new;
        }

        else if (s[i] == '(')
        {
            struct Token_Type* new = Create_Parenthese_Token(1);
            count++;
            res = realloc(res,count*sizeof(struct Token_Type));
            res[count-1] = new;
        }

        else if (s[i] == ')')
        {
            struct Token_Type* new = Create_Parenthese_Token(0);
            count++;
            res = realloc(res,count*sizeof(struct Token_Type));
            res[count-1] = new;
        }
        i++;
    }
    *len = count;
    return res;
}

struct Token_Type** RPN(struct Token_Type** list, int len, int* len_rpn)
{
    int count_res = 0;
    struct Stack* stack_operators = createStack(len);
    struct Stack* stack_output = createStack(len);
    
    for (int i = 0; i < len; i++)
    {
        if (list[i]->operands != NULL)
        {
            push(stack_output,list[i]);
            count_res++;
            continue;
        }
        else if (list[i]->operator != NULL)
        {
            while(!stack_isEmpty(stack_operators) && 
                  seek(stack_operators)->operator != NULL &&
                  seek(stack_operators)->operator->precedence >= list[i]->operator->precedence)
            {
                push(stack_output,pop(stack_operators));
                count_res++;
            }
            push(stack_operators,list[i]);
        }
        else if (list[i]->paranthese != NULL && list[i]->paranthese->is_left == 1)
        {
            push(stack_operators,list[i]);
        }
        else if (list[i]->paranthese != NULL && list[i]->paranthese->is_right == 1)
        {
            while(stack_isEmpty(stack_operators) == 0)
            {
                if (seek(stack_operators)->paranthese == NULL)
                {
                    push(stack_output,pop(stack_operators));
                    count_res++;
                    continue;
                }
                else if (seek(stack_operators)->paranthese->is_left != 1)
                {
                    push(stack_output,pop(stack_operators));
                    count_res++;
                    continue;
                }
                pop(stack_operators);
                break;
            }
        }
    }
    while (!stack_isEmpty(stack_operators))
    {
        push(stack_output,pop(stack_operators));
        count_res++;
    }
    *len_rpn = count_res;
    return stack_output->array;
}

struct Tree* Build_Tree(struct Token_Type** rpn, int len)
{
    struct Stack2* stack_node = createStack2(len);
    for (int i = 0; i < len ; i++)
    {
        if (rpn[i]->operands != NULL)
        {
            struct Tree* node = create_tree(rpn[i]);
            push2(stack_node,node); 
        }
        else if (rpn[i]->operator != NULL)
        {
            if (rpn[i]->operator->nb_operands == 2)
            {        
                struct Tree* node2 = pop2(stack_node);
                struct Tree* node1 = pop2(stack_node);
                struct Tree* node = create_tree(rpn[i]);
                node->left = node1;
                node->right = node2;
                push2(stack_node,node);
            }
            else if (rpn[i]->operator->nb_operands == 1)
            {
                struct Tree* node1 = pop2(stack_node);
                struct Tree* node = create_tree(rpn[i]);
                node->left = node1;
                push2(stack_node,node);               
            }
        }
    }
    return pop2(stack_node);
}

int computeTree(struct Tree* tree)
{
    if (tree->left == NULL)
        return tree->data->operands->value;

    int left = computeTree(tree->left);
    int right = computeTree(tree->right);
    if (tree->data->operator->operation_type == plus)
        return left + right;
    else if (tree->data->operator->operation_type == minus)
        return left - right;
    else if (tree->data->operator->operation_type == mult)
        return left * right;
    else if (tree->data->operator->operation_type == division)
        return left / right;
    else if (tree->data->operator->operation_type == mod)
        return left % right;
    else if (tree->data->operator->operation_type == power)
        return (int)pow((double)left,(double)right);
    return 0;
}

/*
int main() //test
{
    char* s = "12*(56-11)+(3+78)";
    int len = 0; 
    int len_rpn = 0;
    struct Token_Type** res = lexer(s,&len);
    struct Token_Type** rpn = RPN(res,len,&len_rpn);
    struct Tree* tree = Build_Tree(rpn,len_rpn);
    int res0 = computeTree(tree);
    printf("%i",res0);
    return 0;
}
*/
