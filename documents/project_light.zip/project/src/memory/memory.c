#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAX_LINE_LENGTH 100

// Fonction pour écrire dans un fichier
void write_in_file(const char *text) {
  FILE *file;
  
  const char *file_name = "save.txt";
  // Ouvre le fichier en mode "append" pour ajouter les données à la fin
  file = fopen(file_name, "a");

  // Si le fichier n'existe pas, il est créé
  if (file == NULL) {
    file = fopen(file_name, "w");
  }

  // Écrit les données dans un nouvelle ligne
  fprintf(file, "%s\n", text);

  // Ferme le fichier
  fclose(file);
}

// Fonction pour lire dans un fichier
char** read_in_file(int* num_lines) {
    FILE *fp;
    char *line = NULL;
    size_t len = 0;
    ssize_t read;
    char **lines = NULL;
    int lines_count = 0;

    fp = fopen("save.txt", "r");
    if (fp == NULL) {
        return NULL;
    }

    while ((read = getline(&line, &len, fp)) != -1) {
        lines_count++;
        lines = (char**)realloc(lines, sizeof(char*) * lines_count);
        lines[lines_count-1] = strdup(line);
    }

    fclose(fp);
    free(line);

    if (*num_lines == 0) {
        *num_lines = lines_count;
    }

    if (*num_lines > lines_count) {
        *num_lines = lines_count;
    }

    char **result = (char**)malloc(sizeof(char*) * (*num_lines));
    int j = 0;
    for (int i = lines_count - (*num_lines); i < lines_count; i++) {
        result[j++] = strdup(lines[i]);
    }

    for (int i = 0; i < lines_count; i++) {
        free(lines[i]);
    }
    free(lines);
    return result;
}

struct MemoryStack {
  int data;
  struct MemoryStack *next;
};

void write_stack(struct MemoryStack **head, int data) {
  struct MemoryStack *new_node = (struct MemoryStack *)malloc(sizeof(struct MemoryStack));
  new_node->data = data;
  new_node->next = *head;
  *head = new_node;
}

int read_stack(struct MemoryStack **head) {
  if (*head == NULL) {
    return -1;
  }
  int data = (*head)->data;
  struct MemoryStack *temp = *head;
  *head = (*head)->next;
  free(temp);
  return data;
}

void clear_all() {
    FILE *f = fopen("save.txt", "w");
    if (f == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return;
    }
    fclose(f);
}

void clear_last() {
    FILE *f = fopen("save.txt", "r+");
    if (f == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return;
    }
    fseek(f, 0, SEEK_END);
    long pos = ftell(f);
    if (pos > 0) {
        pos--;
        while (pos > 0 && fgetc(f) != '\n') {
            fseek(f, --pos, SEEK_SET);
        }
        if (pos > 0) {
            fseek(f, pos, SEEK_SET);
        }
        ftruncate(fileno(f), pos);
        printf("Dernière ligne supprimée.\n");
    } else {
        printf("Aucune ligne à supprimer.\n");
    }
    fclose(f);
}
